#!/usr/bin/env bash
# FadanOS builder (native shell, no browser). Run inside WSL / Linux:   sudo bash build.sh
# Output: out/vmlinuz-virt, out/initramfs-virt, out/fadanos.img   (then: bash run.sh  or  run.bat)
set -euo pipefail
[ "$EUID" = 0 ] || { echo "Run with sudo"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd); W=/tmp/fadanos; OUT=$HERE/out
apt-get update -qq && apt-get install -y -qq curl e2fsprogs >/dev/null
rm -rf $W; mkdir -p $W $OUT; cd $W
B=https://dl-cdn.alpinelinux.org/alpine/latest-stable
F=$(curl -fsL $B/releases/x86_64/latest-releases.yaml | grep -m1 -o 'alpine-minirootfs-[0-9.]*-x86_64.tar.gz')
curl -fsLO $B/releases/x86_64/$F; mkdir root; tar xzf $F -C root
printf "http://dl-cdn.alpinelinux.org/alpine/latest-stable/main\nhttp://dl-cdn.alpinelinux.org/alpine/latest-stable/community\n" > root/etc/apk/repositories
cp /etc/resolv.conf root/etc/resolv.conf
mkdir root/src; cp "$HERE"/src/shell.c "$HERE"/src/stb_truetype.h root/src/
mount --bind /proc root/proc; mount --bind /dev root/dev; mount --bind /sys root/sys
trap 'umount -l root/proc root/dev root/sys 2>/dev/null || true' EXIT

chroot root /bin/sh -eu <<'CH'
mkdir -p /var/cache/apk; ln -sf /var/cache/apk /etc/apk/cache
apk add --no-cache linux-virt mkinitfs kmod eudev tzdata font-noto curl ca-certificates wpa_supplicant iw ncurses ncurses-terminfo-base bash modemmanager dbus build-base linux-headers
apk add --no-cache font-dejavu || apk add --no-cache ttf-dejavu || true
echo 'features="base ext4 virtio scsi ata ide usb"' > /etc/mkinitfs/mkinitfs.conf
K=$(ls /lib/modules); depmod "$K"; mkinitfs -o /boot/initramfs-virt "$K"
ln -sf /usr/share/zoneinfo/Europe/Berlin /etc/localtime
# compile the native shell, then throw the compiler away
gcc -O2 -o /usr/local/bin/fadan-shell /src/shell.c -lm
apk del --no-cache build-base linux-headers; rm -rf /src
# offline package cache: download the Linux Apps list once, then uninstall again (the .apk files stay cached)
apk update || true
PRE="nano vim micro htop mc python3 git lynx ncdu nodejs"
apk add $PRE || true
apk del $PRE || true
CH

echo "nameserver 10.0.2.3" > root/etc/resolv.conf
mkdir -p root/var/lib/fadan
cat > root/etc/inittab <<'EOF2'
::sysinit:/usr/local/bin/fadan-boot
tty1::respawn:/usr/local/bin/fadan-session
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
EOF2
for f in fadan-boot fadan-net fadan-wifi fadan-status fadan-mobile udhcpc-script; do cp "$HERE/src/$f" root/usr/local/bin/$f; done
cp "$HERE/src/fadan-session" root/usr/local/bin/fadan-session
mkdir -p root/usr/share/fonts/fadan; cp "$HERE/fonts/DejaVuSans.ttf" "$HERE/fonts/DejaVuSansMono.ttf" root/usr/share/fonts/fadan/
cp "$HERE/src/fadan-apt" root/usr/local/bin/apt; cp "$HERE/src/fadan-apt" root/usr/local/bin/apt-get; cp "$HERE/src/fadan-apt" root/usr/local/bin/apt-cache
cp "$HERE/src/fadan-sudo" root/usr/local/bin/sudo; mkdir -p root/etc/profile.d; cp "$HERE/src/profile-fadan.sh" root/etc/profile.d/fadan.sh
cp "$HERE/src/gui" root/usr/local/bin/gui; cp "$HERE/src/fadan-gui-run" "$HERE/src/fadan-gui-setup" root/usr/local/bin/
chmod +x root/usr/local/bin/gui root/usr/local/bin/fadan-* root/usr/local/bin/apt root/usr/local/bin/apt-get root/usr/local/bin/apt-cache root/usr/local/bin/sudo

cp root/boot/vmlinuz-virt root/boot/initramfs-virt $OUT/
umount -l root/proc root/dev root/sys; trap - EXIT; sleep 1
mke2fs -q -t ext4 -L fadanos -d root $W/fadanos.img ${IMGSIZE:-8G}
cp --sparse=always $W/fadanos.img $OUT/fadanos.img
chown -R "${SUDO_USER:-root}": $OUT; chmod 644 $OUT/*
echo "Done. Now run: bash run.sh   (Windows: run.bat)"
