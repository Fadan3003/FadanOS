#!/usr/bin/env bash
# Puts the newest prebuilt shell, font and session script into the existing image (no rebuild).
# Usage: bash update.sh   (then bash run.sh)
export PATH=$PATH:/sbin:/usr/sbin
cd "$(dirname "$0")"
for f in bin/fadan-shell src/fadan-session src/fadan-boot src/fadan-net src/fadan-wifi src/fadan-status src/fadan-mobile src/udhcpc-script src/apk-repositories src/fadan-apt src/gui src/fadan-gui-run src/fadan-gui-setup src/fadan-sudo src/profile-fadan.sh fonts/DejaVuSans.ttf fonts/DejaVuSansMono.ttf; do [ -s $f ] || { echo "FEHLER: $f fehlt. Entpacke die komplette FadanOS.zip."; exit 1; }; done
[ -s out/fadanos.img ] || { echo "FEHLER: out/fadanos.img fehlt. Erst: sudo bash build.sh"; exit 1; }
command -v debugfs >/dev/null || sudo apt-get install -y e2fsprogs
[ -w out/fadanos.img ] || sudo chown "$USER": out/*
C=$(mktemp); trap 'rm -f $C' EXIT; P=$PWD
cat > $C <<EOC
rm /usr/local/bin/fadan-shell
write $P/bin/fadan-shell /usr/local/bin/fadan-shell
sif /usr/local/bin/fadan-shell mode 0100755
rm /usr/local/bin/fadan-session
write $P/src/fadan-session /usr/local/bin/fadan-session
sif /usr/local/bin/fadan-session mode 0100755
rm /etc/apk/repositories
write $P/src/apk-repositories /etc/apk/repositories
mkdir /var/cache/apk
symlink /etc/apk/cache /var/cache/apk
rm /usr/local/bin/fadan-boot
write $P/src/fadan-boot /usr/local/bin/fadan-boot
sif /usr/local/bin/fadan-boot mode 0100755
rm /usr/local/bin/fadan-net
write $P/src/fadan-net /usr/local/bin/fadan-net
sif /usr/local/bin/fadan-net mode 0100755
rm /usr/local/bin/fadan-wifi
write $P/src/fadan-wifi /usr/local/bin/fadan-wifi
sif /usr/local/bin/fadan-wifi mode 0100755
rm /usr/local/bin/fadan-status
write $P/src/fadan-status /usr/local/bin/fadan-status
sif /usr/local/bin/fadan-status mode 0100755
rm /usr/local/bin/fadan-mobile
write $P/src/fadan-mobile /usr/local/bin/fadan-mobile
sif /usr/local/bin/fadan-mobile mode 0100755
rm /usr/local/bin/udhcpc-script
write $P/src/udhcpc-script /usr/local/bin/udhcpc-script
sif /usr/local/bin/udhcpc-script mode 0100755
rm /usr/local/bin/gui
write $P/src/gui /usr/local/bin/gui
sif /usr/local/bin/gui mode 0100755
rm /usr/local/bin/fadan-gui-run
write $P/src/fadan-gui-run /usr/local/bin/fadan-gui-run
sif /usr/local/bin/fadan-gui-run mode 0100755
rm /usr/local/bin/fadan-gui-setup
write $P/src/fadan-gui-setup /usr/local/bin/fadan-gui-setup
sif /usr/local/bin/fadan-gui-setup mode 0100755
rm /usr/local/bin/apt
write $P/src/fadan-apt /usr/local/bin/apt
sif /usr/local/bin/apt mode 0100755
rm /usr/local/bin/apt-get
write $P/src/fadan-apt /usr/local/bin/apt-get
sif /usr/local/bin/apt-get mode 0100755
rm /usr/local/bin/apt-cache
write $P/src/fadan-apt /usr/local/bin/apt-cache
sif /usr/local/bin/apt-cache mode 0100755
rm /usr/local/bin/sudo
write $P/src/fadan-sudo /usr/local/bin/sudo
sif /usr/local/bin/sudo mode 0100755
rm /etc/profile.d/fadan.sh
write $P/src/profile-fadan.sh /etc/profile.d/fadan.sh
mkdir /usr/share/fonts/fadan
rm /usr/share/fonts/fadan/DejaVuSans.ttf
write $P/fonts/DejaVuSans.ttf /usr/share/fonts/fadan/DejaVuSans.ttf
rm /usr/share/fonts/fadan/DejaVuSansMono.ttf
write $P/fonts/DejaVuSansMono.ttf /usr/share/fonts/fadan/DejaVuSansMono.ttf
EOC
LOG=$(debugfs -w -f $C out/fadanos.img 2>&1)
SZ=$(debugfs -R "stat /usr/local/bin/fadan-shell" out/fadanos.img 2>/dev/null | grep -o "Size: [0-9]*")
FZ=$(debugfs -R "stat /usr/share/fonts/fadan/DejaVuSans.ttf" out/fadanos.img 2>/dev/null | grep -o "Size: [0-9]*")
if [ -z "$SZ" ] || [ -z "$FZ" ]; then echo "FEHLER beim Schreiben ins Image:"; echo "$LOG" | grep -v "ext2_lookup"; echo "Falls 'allocate block': Image ist voll, bitte neu bauen: sudo bash build.sh"; exit 1; fi
echo "OK. Jetzt: bash run.sh"
echo "Hinweis: Browser und Terminal-Programme brauchen Netzwerk; curl, iw, wpa_supplicant kommen nur mit: sudo bash build.sh"
