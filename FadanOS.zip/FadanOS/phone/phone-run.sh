#!/data/data/com.termux/files/usr/bin/sh
# Starts FadanOS in QEMU on an Android phone (Termux).
# Then open a VNC viewer app and connect to  localhost  port 5901  (no password).
# Smaller/faster:  RES=360x640 sh phone-run.sh
cd "$(dirname "$0")"
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo "Install QEMU first:  pkg install qemu-system-x86-64-headless"; exit 1; }
RES=${RES:-540x960}; XR=${RES%x*}; YR=${RES#*x}
echo "FadanOS is starting. Connect your VNC viewer to localhost:5901 ..."
exec qemu-system-x86_64 -machine q35 -cpu max -accel tcg,thread=multi -smp 4 -m 1536 \
  -kernel vmlinuz-virt -initrd initramfs-virt \
  -append "root=/dev/vda rootfstype=ext4 rw quiet loglevel=0 console=ttyS0 vt.global_cursor_default=0 video=Virtual-1:${XR}x${YR}" \
  -drive file=fadanos.img,format=raw,if=virtio \
  -device virtio-vga,edid=on,xres=$XR,yres=$YR -display none -vnc 127.0.0.1:1 \
  -device qemu-xhci -device usb-tablet -device usb-kbd -nic user,model=virtio-net-pci
