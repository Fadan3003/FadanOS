#!/usr/bin/env bash
# Enlarges the FadanOS disk without rebuilding. Close QEMU first.  Usage: bash grow.sh [size]   (default 8G)
set -e; export PATH=$PATH:/sbin:/usr/sbin
cd "$(dirname "$0")/out"; SIZE=${1:-8G}
[ -w fadanos.img ] || sudo chown "$USER": fadanos.img
truncate -s "$SIZE" fadanos.img
e2fsck -fy fadanos.img || true
resize2fs fadanos.img
echo "Disk is now $SIZE."
