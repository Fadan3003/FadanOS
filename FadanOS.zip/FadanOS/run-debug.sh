#!/usr/bin/env bash
# FadanOS DEBUG launcher (kernel messages visible) for Linux / WSL2 / Chromebook.  Usage: bash run.sh
set -e
cd "$(dirname "$0")/out"
[ -w fadanos.img ] || sudo chown "$USER": vmlinuz-virt initramfs-virt fadanos.img
command -v qemu-system-x86_64 >/dev/null || { sudo apt-get update -qq && sudo apt-get install -y qemu-system-x86 qemu-system-gui; }
if [ -w /dev/kvm ]; then ACCEL="-accel kvm -cpu host"; else ACCEL="-accel tcg,thread=multi -cpu max"; echo "No KVM, using slower emulation"; fi
AVAIL=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo); MEM=$((AVAIL-500)); [ $MEM -gt 2048 ] && MEM=2048; [ $MEM -lt 512 ] && MEM=512
RES=${RES:-360x640}   # window size; bigger: RES=540x960 bash run.sh
XR=${RES%x*}; YR=${RES#*x}
DISP="gtk,zoom-to-fit=off"; [ "${1:-}" = sdl ] && DISP="sdl"   # "bash run.sh sdl" keeps the aspect ratio when you resize the window
exec qemu-system-x86_64 -name FadanOS -machine q35 $ACCEL -smp 2 -m $MEM \
  -kernel vmlinuz-virt -initrd initramfs-virt \
  -append "root=/dev/vda rootfstype=ext4 rw loglevel=7 console=tty0 video=Virtual-1:${XR}x${YR}" \
  -drive file=fadanos.img,format=raw,if=virtio \
  -device virtio-vga,edid=on,xres=$XR,yres=$YR -display $DISP \
  -device qemu-xhci -device usb-tablet -device usb-kbd -nic user,model=virtio-net-pci
