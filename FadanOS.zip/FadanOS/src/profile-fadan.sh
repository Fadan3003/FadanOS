export PS1='\u@fadanos:\w\$ '
alias ll='ls -la'
alias update='sudo apt update && sudo apt upgrade'
