// FadanOS native shell: draws straight to /dev/fb0, reads /dev/input/event*. No X, no Wayland, no browser.
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <sys/reboot.h>
#include <dirent.h>
#include <ctype.h>
#include <strings.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <net/if.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <termios.h>
#include <errno.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <linux/kd.h>
#define STB_TRUETYPE_IMPLEMENTATION
#include "stb_truetype.h"
typedef uint32_t u32;
#define CL(v,a,b) ((v)<(a)?(a):(v)>(b)?(b):(v))
#define SAVE "/var/lib/fadan"
static u32 *buf,*wpb; static int W=540,H=960; static float SC=1.5f,OX=0,OY=0;
static struct{float ox,oy,s,a;}X={0,0,1,1};
static double NOW,lastIn; static int busy,slow;
static inline float tx(float x){return OX+(X.ox+x*X.s)*SC;}
static inline float ty(float y){return OY+(X.oy+y*X.s)*SC;}
static float lerp(float a,float b,float t){return a+(b-a)*t;}
static u32 mix(u32 a,u32 b,float t){t=CL(t,0,1);int r=lerp(a>>16&255,b>>16&255,t),g=lerp(a>>8&255,b>>8&255,t),c=lerp(a&255,b&255,t);return r<<16|g<<8|c;}
static void idX(void){X.ox=X.oy=0;X.s=1;X.a=1;}
static void setX(float s,float cx,float cy,float a){X.s=s;X.ox=cx*(1-s);X.oy=cy*(1-s);X.a=a;}
static inline void bl(int x,int y,u32 c,float a){
 if((unsigned)x>=(unsigned)W||(unsigned)y>=(unsigned)H)return; a*=X.a; if(a<=.004f)return; int i=a>=1?256:(int)(a*256);
 u32 d=buf[y*W+x]; int r=((d>>16&255)*(256-i)+(c>>16&255)*i)>>8,g=((d>>8&255)*(256-i)+(c>>8&255)*i)>>8,b=((d&255)*(256-i)+(c&255)*i)>>8; buf[y*W+x]=r<<16|g<<8|b;}
static void RG(float x,float y,float w,float h,float r,u32 c1,u32 c2,float a){
 float x0=tx(x),y0=ty(y),x1=tx(x+w),y1=ty(y+h),R=r*X.s*SC,hw=(x1-x0)/2,hh=(y1-y0)/2,cx=x0+hw,cy=y0+hh; if(R>hw)R=hw; if(R>hh)R=hh;
 int ax=fmaxf(floorf(x0)-1,0),bx=fminf(ceilf(x1)+1,W),ay=fmaxf(floorf(y0)-1,0),by=fminf(ceilf(y1)+1,H);
 for(int j=ay;j<by;j++)for(int i=ax;i<bx;i++){
  float qx=fabsf(i+.5f-cx)-hw+R,qy=fabsf(j+.5f-cy)-hh+R,d; if(qx>0&&qy>0)d=sqrtf(qx*qx+qy*qy)-R; else d=fmaxf(qx,qy)-R;
  float cv=.5f-d; if(cv<=0)continue; if(cv>1)cv=1; u32 c=c1; if(c1!=c2)c=mix(c1,c2,((i-x0)/(x1-x0)+(j-y0)/(y1-y0))*.5f); bl(i,j,c,cv*a);}}
static void RR(float x,float y,float w,float h,float r,u32 c,float a){RG(x,y,w,h,r,c,c,a);}
static u32*wpbl;
static void blurpass(const u32*src,u32*dst,int w,int h,int r,int horiz){int n=horiz?w:h,m=horiz?h:w,den=2*r+1;
 for(int l=0;l<m;l++){int rs=0,gs=0,bs=0;
#define IDX(i) (horiz?(l)*w+(i):(i)*w+(l))
  for(int k=-r;k<=r;k++){u32 c=src[IDX(CL(k,0,n-1))];rs+=c>>16&255;gs+=c>>8&255;bs+=c&255;}
  for(int i=0;i<n;i++){dst[IDX(i)]=(u32)((rs/den)<<16|(gs/den)<<8|(bs/den));u32 a=src[IDX(CL(i+r+1,0,n-1))],b=src[IDX(CL(i-r,0,n-1))];
   rs+=(a>>16&255)-(b>>16&255);gs+=(a>>8&255)-(b>>8&255);bs+=(a&255)-(b&255);}}}
static void mkblur(void){if(!wpbl)wpbl=malloc((size_t)W*H*4);u32*t=malloc((size_t)W*H*4);if(!t||!wpbl){free(t);return;}int r=(int)(8*SC)+2;
 blurpass(wpb,t,W,H,r,1);blurpass(t,wpbl,W,H,r,0);blurpass(wpbl,t,W,H,r,1);blurpass(t,wpbl,W,H,r,0);free(t);}
static void GL(float x,float y,float w,float h,float r,u32 tint,float ta,float a){
 float x0=tx(x),y0=ty(y),x1=tx(x+w),y1=ty(y+h),R=r*X.s*SC,hw=(x1-x0)/2,hh=(y1-y0)/2,cx=x0+hw,cy=y0+hh;if(R>hw)R=hw;if(R>hh)R=hh;
 int ax=fmaxf(floorf(x0)-1,0),bx=fminf(ceilf(x1)+1,W),ay=fmaxf(floorf(y0)-1,0),by=fminf(ceilf(y1)+1,H);
 for(int j=ay;j<by;j++)for(int i=ax;i<bx;i++){float qx=fabsf(i+.5f-cx)-hw+R,qy=fabsf(j+.5f-cy)-hh+R,d;if(qx>0&&qy>0)d=sqrtf(qx*qx+qy*qy)-R;else d=fmaxf(qx,qy)-R;
  float cv=.5f-d;if(cv<=0)continue;if(cv>1)cv=1;u32 c=wpbl?wpbl[j*W+i]:0xDDDDDD;bl(i,j,mix(c,tint,ta),cv*a);}}

// real-time backdrop blur: blurs whatever is already drawn in the frame (area given in device pixels), strength 0..1
static u32*bs1,*bs2;static size_t bscap;static int*bxi0,*bxi1,*bxw;static int bxcap;
static int blurOff;
static void blur_area(int x0,int y0,int x1,int y1,float amt){if(blurOff)return;x0=CL(x0,0,W);x1=CL(x1,0,W);y0=CL(y0,0,H);y1=CL(y1,0,H);int w=x1-x0,h=y1-y0;if(w<8||h<8||amt<.01f)return;
 int k=W>=500?6:4,sw=(w+k-1)/k,sh=(h+k-1)/k;size_t need=(size_t)sw*sh;
 if(need>bscap){bs1=realloc(bs1,need*4);bs2=realloc(bs2,need*4);bscap=need;}if(w>bxcap){bxi0=realloc(bxi0,w*sizeof(int));bxi1=realloc(bxi1,w*sizeof(int));bxw=realloc(bxw,w*sizeof(int));bxcap=w;}
 for(int j=0;j<sh;j++)for(int i=0;i<sw;i++){int px=x0+i*k+k/2,py=y0+j*k+k/2;int xa=CL(px-1,0,W-1),xb=CL(px+1,0,W-1),ya=CL(py-1,0,H-1),yb=CL(py+1,0,H-1);
  u32 a=buf[ya*W+xa],b=buf[ya*W+xb],c=buf[yb*W+xa],d=buf[yb*W+xb];
  int r=((a>>16&255)+(b>>16&255)+(c>>16&255)+(d>>16&255))>>2,g=((a>>8&255)+(b>>8&255)+(c>>8&255)+(d>>8&255))>>2,bb=((a&255)+(b&255)+(c&255)+(d&255))>>2;bs1[j*sw+i]=(u32)(r<<16|g<<8|bb);}
 blurpass(bs1,bs2,sw,sh,2,1);blurpass(bs2,bs1,sw,sh,2,0);blurpass(bs1,bs2,sw,sh,2,1);blurpass(bs2,bs1,sw,sh,2,0);
 for(int x=0;x<w;x++){float fx=(x+.5f)/k-.5f;int ix=(int)floorf(fx);int wx=(int)((fx-ix)*256);bxi0[x]=CL(ix,0,sw-1);bxi1[x]=CL(ix+1,0,sw-1);bxw[x]=wx;}
 int ia=(int)(CL(amt,0,1)*256);
 for(int y=0;y<h;y++){float fy=(y+.5f)/k-.5f;int iy=(int)floorf(fy);int wy=(int)((fy-iy)*256);const u32*r0=bs1+CL(iy,0,sh-1)*sw,*r1=bs1+CL(iy+1,0,sh-1)*sw;u32*row=buf+(size_t)(y0+y)*W+x0;
  for(int x=0;x<w;x++){u32 a=r0[bxi0[x]],b=r0[bxi1[x]],c=r1[bxi0[x]],d=r1[bxi1[x]];int wx=bxw[x];u32 o=0;
   for(int sft=16;sft>=0;sft-=8){int ta=(int)(a>>sft&255)*(256-wx)+(int)(b>>sft&255)*wx,tb=(int)(c>>sft&255)*(256-wx)+(int)(d>>sft&255)*wx;int v=((ta>>8)*(256-wy)+(tb>>8)*wy)>>8;int org=(int)(row[x]>>sft&255);o|=(u32)((ia>=250?v:((org*(256-ia)+v*ia)>>8))&255)<<sft;}
   row[x]=o;}}}

static void ring(float cx,float cy,float r,float w,u32 c,float a,float frac){
 float dx=tx(cx),dy=ty(cy),R=r*X.s*SC,Wd=w*X.s*SC,E=R+Wd+2;
 for(int j=fmaxf(dy-E,0);j<fminf(dy+E,H);j++)for(int i=fmaxf(dx-E,0);i<fminf(dx+E,W);i++){
  float px=i+.5f-dx,py=j+.5f-dy,d=fabsf(sqrtf(px*px+py*py)-R)-Wd/2,cv=.5f-d; if(cv<=0)continue;
  if(frac<1){float an=atan2f(px,-py);if(an<0)an+=6.2831853f;if(an>frac*6.2831853f)continue;} bl(i,j,c,fminf(cv,1)*a);}}
static void line(float x1,float y1,float x2,float y2,float w,u32 c,float a){
 float ax=tx(x1),ay=ty(y1),bx=tx(x2),by=ty(y2),hw=w*X.s*SC/2,vx=bx-ax,vy=by-ay,l2=vx*vx+vy*vy+1e-6f;
 for(int j=fmaxf(fminf(ay,by)-hw-2,0);j<fminf(fmaxf(ay,by)+hw+2,H);j++)for(int i=fmaxf(fminf(ax,bx)-hw-2,0);i<fminf(fmaxf(ax,bx)+hw+2,W);i++){
  float px=i+.5f-ax,py=j+.5f-ay,t=CL((px*vx+py*vy)/l2,0,1),ex=px-vx*t,ey=py-vy*t,cv=.5f-(sqrtf(ex*ex+ey*ey)-hw); if(cv>0)bl(i,j,c,fminf(cv,1)*a);}}
// ---------- text ----------
static stbtt_fontinfo FI[5]; static int fontok,fbok;
typedef struct{int cp,sz,f,w,h,xo,yo,used;float adv;unsigned char*bm;}Gl; static Gl gc[4096];
static Gl*glyph(int cp,int sz,int f){unsigned k=((unsigned)cp*2654435761u+sz*97+f)&4095;
 for(int n=0;n<4096;n++,k=(k+1)&4095){Gl*g=&gc[k]; if(!g->used){int ff=f;if(f<2&&cp>127&&fbok&&!stbtt_FindGlyphIndex(&FI[f],cp))ff=2+f;float s=stbtt_ScaleForPixelHeight(&FI[ff],sz);int a,l;g->used=1;g->cp=cp;g->sz=sz;g->f=f;
   g->bm=stbtt_GetCodepointBitmap(&FI[ff],s,s,cp,&g->w,&g->h,&g->xo,&g->yo);stbtt_GetCodepointHMetrics(&FI[ff],cp,&a,&l);g->adv=a*s;return g;}
  if(g->cp==cp&&g->sz==sz&&g->f==f)return g;}
 for(int n=0;n<4096;n++){if(gc[n].bm)free(gc[n].bm);} memset(gc,0,sizeof gc);return glyph(cp,sz,f);}
static int u8(const char**p){const unsigned char*s=(const unsigned char*)*p;int c=*s++;if(c>=0xE0&&s[0]&&s[1]){c=(c&15)<<12|(s[0]&63)<<6|(s[1]&63);s+=2;}else if(c>=0xC0&&s[0]){c=(c&31)<<6|(s[0]&63);s++;}*p=(const char*)s;return c;}
static float tws(const char*s,int ds,int f){float w=0;while(*s)w+=glyph(u8(&s),ds,f)->adv;return w;}
static float tw(const char*s,float sz,int f){return tws(s,(int)(sz*X.s*SC+.5f),f)/(X.s*SC);}
static float T(float x,float y,float sz,const char*s,u32 c,float a,int al,int f){
 int ds=(int)(sz*X.s*SC+.5f); if(ds<3||!fontok)return 0;
 float w=tws(s,ds,f),cx=tx(x); if(al==1)cx-=w/2; else if(al==2)cx-=w;
 float sc=stbtt_ScaleForPixelHeight(&FI[f],ds);int as;stbtt_GetFontVMetrics(&FI[f],&as,0,0);float by=ty(y)+as*sc;
 for(const char*p=s;*p;){Gl*g=glyph(u8(&p),ds,f);if(g->bm){int gx=(int)floorf(cx+.5f)+g->xo,gy=(int)floorf(by+.5f)+g->yo;
   for(int j=0;j<g->h;j++)for(int i=0;i<g->w;i++){int v=g->bm[j*g->w+i];if(v)bl(gx+i,gy+j,c,a*v/255.f);}}cx+=g->adv;}

 return w/(X.s*SC);}
static void tri(float x1,float y1,float x2,float y2,float x3,float y3,u32 c,float a){
 float p[3][2]={{tx(x1),ty(y1)},{tx(x2),ty(y2)},{tx(x3),ty(y3)}};float ar=(p[1][0]-p[0][0])*(p[2][1]-p[0][1])-(p[1][1]-p[0][1])*(p[2][0]-p[0][0]),sg=ar>0?1:-1;
 int ax=fmaxf(floorf(fminf(p[0][0],fminf(p[1][0],p[2][0])))-1,0),bx=fminf(ceilf(fmaxf(p[0][0],fmaxf(p[1][0],p[2][0])))+1,W),ay=fmaxf(floorf(fminf(p[0][1],fminf(p[1][1],p[2][1])))-1,0),by=fminf(ceilf(fmaxf(p[0][1],fmaxf(p[1][1],p[2][1])))+1,H);
 for(int j=ay;j<by;j++)for(int i=ax;i<bx;i++){float dm=1e9f;for(int k=0;k<3;k++){float*q=p[k],*r=p[(k+1)%3];float ex=r[0]-q[0],ey=r[1]-q[1],d=sg*(ex*(j+.5f-q[1])-ey*(i+.5f-q[0]))/sqrtf(ex*ex+ey*ey+1e-6f);if(d<dm)dm=d;}
  float cv=CL(.5f+dm,0,1);if(cv>0)bl(i,j,c,cv*a);}}
static void chev(float cx,float cy,float s,int d,u32 c,float a){float w=2.8f;
 if(d==0){line(cx-s,cy+s*.5f,cx,cy-s*.5f,w,c,a);line(cx,cy-s*.5f,cx+s,cy+s*.5f,w,c,a);}
 else if(d==1){line(cx+s*.5f,cy-s,cx-s*.5f,cy,w,c,a);line(cx-s*.5f,cy,cx+s*.5f,cy+s,w,c,a);}
 else if(d==3){line(cx-s,cy-s*.5f,cx,cy+s*.5f,w,c,a);line(cx,cy+s*.5f,cx+s,cy-s*.5f,w,c,a);}
 else{line(cx-s*.5f,cy-s,cx+s*.5f,cy,w,c,a);line(cx+s*.5f,cy,cx-s*.5f,cy+s,w,c,a);}}
// ---------- settings and theme ----------
typedef struct{int fadan,dark,h24,wp,br,night,autolock,anim,tz,airplane,mobile,accent,noblur;}Set; static Set S={1,0,1,0,100,0,0,1,0,0,0,0,0};
static void settz(void);
static const u32 ACS[6]={0x0A7CFF,0x7C5CF0,0x1FA463,0xF08A1C,0xE0407B,0x14A3B8};
static u32 ACC(void){return S.fadan?0xA70000:ACS[S.accent%6];}
static u32 BG(void){return S.dark?0x0E0E11:0xF4F2F1;} static u32 CARD(void){return S.dark?0x1C1C21:0xFFFFFF;}
static u32 INK(void){return S.dark?0xF2F2F4:0x1D1D20;} static u32 MUT(void){return S.dark?0x9A9AA2:0x76767D;}
static u32 LINE(void){return S.dark?0x2C2C33:0xE6E4E5;} static u32 GLS(void){return S.dark?0x202026:0xF4F2F3;}
static void sset(void){FILE*f=fopen(SAVE"/set.bin","wb");if(f){fwrite(&S,sizeof S,1,f);fclose(f);}}
static void mkwp(void){
 typedef struct{float x,y,r;u32 c;}Bl;
 static const struct{u32 base;Bl b[4];}WM[6]={
  {0xF3F0F7,{{.08f,.04f,.95f,0},{.98f,.45f,.85f,0xC9B8FF},{.3f,1.f,.95f,0xBFE5FF},{.95f,0.f,.6f,0xFFD7C9}}},
  {0xFFEBDD,{{.1f,.92f,.95f,0xFF9F8A},{.95f,.8f,.85f,0xC77DFF},{.5f,.05f,.9f,0xFFD27D},{0.f,.4f,.6f,0xFF7EB3}}},
  {0xE6F4FF,{{0.f,0.f,.95f,0x7FC8FF},{1.f,.5f,.95f,0x5B7CFA},{.2f,1.f,.95f,0x7FE3D8},{.8f,0.f,.55f,0xBDE0FF}}},
  {0xEAF6EC,{{.1f,.1f,.95f,0x9BDDB0},{.9f,.6f,.95f,0x3FA38F},{.3f,1.f,.85f,0xD4F0A0},{1.f,0.f,.55f,0xB6E6D4}}},
  {0xFFF4E6,{{.9f,.1f,.95f,0xFFC27A},{.1f,.6f,.95f,0xFF9E8A},{.8f,1.f,.85f,0xFFE08A},{0.f,0.f,.55f,0xFFD6BD}}},
  {0xE9ECF2,{{0.f,0.f,.95f,0xB8C0D0},{1.f,.5f,.95f,0x6B7691},{.3f,1.f,.95f,0xA4ADBF},{.9f,0.f,.55f,0xD5DBE6}}}};
 int w=CL(S.wp,0,5);
 for(int y=0;y<H;y++)for(int x=0;x<W;x++){float u=x/(float)W,v=y/(float)H;u32 c=WM[w].base;
  for(int k=0;k<4;k++){const Bl*b=&WM[w].b[k];float dx=u-b->x,dy=(v-b->y)*.72f,d=sqrtf(dx*dx+dy*dy),t=powf(CL(1-d/b->r,0,1),1.7f)*(k==0?.85f:.9f);c=mix(c,b->c?b->c:mix(ACC(),0xFFFFFF,.5f),t);}
  if(S.dark)c=mix(c,0x050508,.64f);wpb[y*W+x]=c;}mkblur();}
// ---------- misc ----------
static int in(float x,float y,float a,float b,float w,float h){return x>=a&&x<a+w&&y>=b&&y<b+h;}
static struct tm tmnow(void){time_t t=time(0);struct tm r;localtime_r(&t,&r);return r;}
static void fmt_time(char*o,int n,struct tm*t){if(S.h24)strftime(o,n,"%H:%M",t);else{strftime(o,n,"%I:%M",t);if(o[0]=='0')memmove(o,o+1,strlen(o));}}
static void doreboot(int how){sync();
#ifndef TEST
 reboot(how);
#endif
}
static void sw(float x,float y,int on){RR(x,y,46,28,14,on?ACC():(S.dark?0x555560:0xC9C9CF),1);RR(on?x+21:x+3,y+3,22,22,11,0xFFFFFF,1);}
static void slider(float x,float y,float w,float v){RR(x,y-3,w,6,3,LINE(),1);RR(x,y-3,fmaxf(6,w*v),6,3,ACC(),1);RR(x+w*v-11,y-11,22,22,11,0xFFFFFF,1);ring(x+w*v,y,11,1,0x000000,.15f,1);}
static u32 GT(void){return S.dark?0x1E1E24:0xFFFFFF;}static float GA(void){return S.dark?.42f:.34f;}
static void pill(float x,float y,float w,float h,u32 c,float a){RG(x,y,w,h,h/2,mix(c,0xFFFFFF,.22f),c,a);}
static void card(float x,float y,float w,float h){if(!S.dark)RR(x,y+1.5f,w,h,18,0,.05f);RR(x,y,w,h,18,CARD(),.92f);}
// ---------- on-screen keyboard ----------
static int kbWant,kbShift,kbNum; static float kbP;
static void key_in(int ch);static int libOn,libEdit;static void lib_key(int ch);
static const char*KR[3][3]={{"qwertyuiop","asdfghjkl","zxcvbnm"},{"1234567890","-/:;()&@\"","#+=.,?!'"},{"[]{}#%^*+=","_\\|~<>$/&","`:;.,?!"}};
static int kbwalk(float px,float py,int draw){
 for(int r=0;r<4;r++){float y=440+r*48,x;const char*row=r<3?KR[kbNum][r]:"";int n=r<3?(int)strlen(row):0;
  if(r==3){float xs[3]={10,74,262},ws[3]={60,184,88};const char*lb[3]={kbNum?"abc":"123","space","return"};int code[3]={2,' ',10};
   for(int k=0;k<3;k++){if(draw){RR(xs[k],y,ws[k],42,9,k==1?CARD():LINE(),1);T(xs[k]+ws[k]/2,y+11,16,lb[k],INK(),1,1,0);}else if(in(px,py,xs[k],y-3,ws[k],48))return code[k];}continue;}
  x=r==0?2:r==1?20:6+46+4;
  if(r==2){if(draw){RR(6,y,46,42,9,kbShift&&!kbNum?ACC():LINE(),1);if(kbNum)T(29,y+11,14,kbNum==1?"#+=":"123",INK(),1,1,1);else{u32 c=kbShift?0xFFFFFF:INK();float cy=y+21;tri(29,cy-8,21,cy+1.5f,37,cy+1.5f,c,1);RR(25.5f,cy,7,7,1.5f,c,1);}RR(308,y,46,42,9,LINE(),1);{float cx=331,cy=y+21;u32 c=INK();RR(cx-4,cy-6.5f,15,13,2.5f,c,1);tri(cx-3,cy-6.5f,cx-3,cy+6.5f,cx-12,cy,c,1);line(cx,cy-3,cx+6,cy+3,1.8f,LINE(),1);line(cx+6,cy-3,cx,cy+3,1.8f,LINE(),1);}}
   else{if(in(px,py,6,y-3,46,48))return 1;if(in(px,py,308,y-3,46,48))return 8;}}
  for(int k=0;k<n;k++){char c=row[k],s[2]={kbShift&&!kbNum?c-32:c,0};
   if(draw){RR(x,y,32,42,9,CARD(),.86f);T(x+16,y+9,19,s,INK(),1,1,0);}else if(in(px,py,x-2,y-3,36,48))return s[0];x+=36;}}
 return 0;}
static void kb_draw(void){if(kbP<.01f)return;X.oy=(1-kbP)*220;X.a=kbP;blur_area(0,(int)ty(430),W,H,kbP);RR(0,430,360,230,0,GLS(),.58f);RR(0,430,360,1,0,0xFFFFFF,.35f);kbwalk(0,0,1);X.oy=0;X.a=1;}
static void kbpress(int k){if(k==1){if(kbNum)kbNum=kbNum==1?2:1;else kbShift^=1;}else if(k==2)kbNum=kbNum?0:1;else{key_in(k);if(k!=8&&k!=10)kbShift=0;}}
// ---------- apps ----------
typedef struct{const char*n;u32 c1,c2;void(*dr)(void);void(*dn)(float,float);void(*mv)(float,float);void(*up)(float,float,int);int live;}App;
static App apps[10]; static int cur=-1;
static void closeApp(void); static float openT,os0=.17f,orad=95,oa0=0,tiox,tioy,tos0=.17f,torad=95;static int swHide=-1,pushLater=-1;
static void title(const char*s){T(20,40,30,s,INK(),1,0,1);}
// --- clock
static int ctab,swr,nl;static double sws,swe,laps[6];
static const char*CITY[4][2]={{"Berlin","Europe/Berlin"},{"London","Europe/London"},{"New York","America/New_York"},{"Tokyo","Asia/Tokyo"}};
static double wall(void){struct timespec t;clock_gettime(CLOCK_REALTIME,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void swfmt(char*o,double s){int c=(int)(s*100)%100,sec=(int)s%60,m=(int)(s/60);sprintf(o,"%02d:%02d.%02d",m,sec,c);}
static void clock_dr(void){
 card(16,40,328,40);RR(19+ctab*162,43,160,34,14,ACC(),1);T(99,50,15,"Clock",ctab?INK():0xFFFFFF,1,1,1);T(261,50,15,"Stopwatch",ctab?0xFFFFFF:INK(),1,1,1);
 if(!ctab){struct tm t=tmnow();double wt=wall();float fs=t.tm_sec+(float)(wt-floor(wt));
  RR(80,104,200,200,100,CARD(),1);ring(180,204,100,2,LINE(),1,1);
  for(int i=0;i<12;i++){float a=i*.5235988f,c=cosf(a),s=sinf(a);line(180+s*86,204-c*86,180+s*94,204-c*94,i%3?2:3.5f,MUT(),1);}
  float hh=(t.tm_hour%12+t.tm_min/60.f)*.5235988f,mm=(t.tm_min+fs/60)*.1047198f,ss=fs*.1047198f;
  line(180,204,180+sinf(hh)*52,204-cosf(hh)*52,6,INK(),1);line(180,204,180+sinf(mm)*76,204-cosf(mm)*76,4,INK(),1);
  line(180-sinf(ss)*14,204+cosf(ss)*14,180+sinf(ss)*88,204-cosf(ss)*88,2,ACC(),1);RR(174,198,12,12,6,ACC(),1);
  char b[16];fmt_time(b,16,&t);T(180,322,42,b,INK(),1,1,1);
  for(int i=0;i<4;i++){struct tm c;time_t n=time(0);setenv("TZ",CITY[i][1],1);tzset();localtime_r(&n,&c);settz();
   float y=394+i*54;card(16,y,328,46);T(34,y+13,16,CITY[i][0],INK(),1,0,0);fmt_time(b,16,&c);T(326,y+13,18,b,INK(),1,2,1);}}
 else{char b[32];double e=swr?swe+NOW-sws:swe;swfmt(b,e);T(180,130,64,b,INK(),1,1,0);
  RR(30,230,150,52,26,CARD(),1);T(105,243,17,swr?"Lap":"Reset",INK(),1,1,1);RR(190,230,140,52,26,swr?0xE0453A:ACC(),1);T(260,243,17,swr?"Stop":"Start",0xFFFFFF,1,1,1);
  for(int i=0;i<nl;i++){float y=310+i*44;char l[40];swfmt(b,laps[nl-1-i]);sprintf(l,"Lap %d",nl-i);T(34,y,16,l,MUT(),1,0,0);T(326,y,17,b,INK(),1,2,0);line(30,y+30,330,y+30,1,LINE(),1);}}}
static void clock_up(float x,float y,int tap){if(!tap)return;
 if(in(x,y,16,40,328,40)){ctab=x>180;return;}
 if(ctab){if(in(x,y,30,230,150,52)){if(swr){if(nl<6)laps[nl++]=swe+NOW-sws;else{memmove(laps,laps+1,5*sizeof(double));laps[5]=swe+NOW-sws;}}else{swe=0;nl=0;}}
  if(in(x,y,190,230,140,52)){if(swr){swe+=NOW-sws;swr=0;}else{sws=NOW;swr=1;}}}}
// --- calculator
static const char*CKL[19]={"AC","\xC2\xB1","%","\xC3\xB7","7","8","9","\xC3\x97","4","5","6","\xE2\x88\x92","1","2","3","+","0",".","="};
static char cdisp[24]="0",cop[4];static double cacc;static int cfr=1,chasop,cpress=-1;
static void ckrect(int i,float*x,float*y,float*w){int r=i<16?i/4:4,c=i<16?i%4:(i==16?0:i==17?2:3);*x=14+c*88;*y=250+r*74;*w=i==16?166:78;}
static void cfmt(double v){if(isnan(v)||isinf(v))strcpy(cdisp,"Error");else{snprintf(cdisp,24,"%.9g",v);}}
static void calc_dr(void){float fs=strlen(cdisp)>9?40:strlen(cdisp)>6?54:68;T(340,140,fs,cdisp,INK(),1,2,0);
 for(int i=0;i<19;i++){float x,y,w;ckrect(i,&x,&y,&w);const char*l=CKL[i];int op=i%4==3&&i<19;if(i==18)op=1;int fn=i<3;
  u32 c=op?ACC():fn?(S.dark?0x4A4A54:0xDDDBDC):CARD();float a=cpress==i?.7f:1;RR(x,y,w,64,32,c,a);T(i==16?x+36:x+w/2,y+15,28,l,op?0xFFFFFF:INK(),1,i==16?0:1,0);}}
static void calc_press(int i){const char*l=CKL[i];double v=atof(cdisp);
 if(l[0]>='0'&&l[0]<='9'){if(cfr||!strcmp(cdisp,"0")){strcpy(cdisp,l);cfr=0;}else if(strlen(cdisp)<12)strcat(cdisp,l);}
 else if(!strcmp(l,".")){if(cfr){strcpy(cdisp,"0.");cfr=0;}else if(!strchr(cdisp,'.'))strcat(cdisp,".");}
 else if(!strcmp(l,"AC")){strcpy(cdisp,"0");chasop=0;cfr=1;}
 else if(i==1)cfmt(-v);else if(i==2)cfmt(v/100);
 else{if(chasop&&!cfr){char o=cop[0];cacc=o=='+'?cacc+v:o=='-'?cacc-v:o=='*'?cacc*v:cacc/v;cfmt(cacc);}else if(!chasop)cacc=v;
  chasop=strcmp(l,"=")!=0;cop[0]=!strcmp(l,"+")?'+':i==11?'-':i==7?'*':'/';cfr=1;}}
static void calc_dn(float x,float y){cpress=-1;for(int i=0;i<19;i++){float a,b,w;ckrect(i,&a,&b,&w);if(in(x,y,a,b,w,64))cpress=i;}}
static void calc_up(float x,float y,int tap){(void)x;(void)y;if(tap&&cpress>=0)calc_press(cpress);cpress=-1;}
// --- notes
#define NN 8
static char notes[NN][1024];static int ned=-1;
static void nsave(void){FILE*f=fopen(SAVE"/notes.dat","wb");if(f){fwrite(notes,sizeof notes,1,f);fclose(f);}}
static void notes_key(int ch){char*s=notes[ned];int n=strlen(s);
 if(ch==8){if(n){do n--;while(n>0&&(s[n]&0xC0)==0x80);s[n]=0;}}else if(n<1020){s[n]=ch==10?'\n':ch;s[n+1]=0;}nsave();}
static void browser_key(int ch);
static void wifi_key(int ch);static void apn_key(int ch);static int setpage,apned;
static void term_key(int ch);static void lapps_key(int ch);
static void key_in(int ch){if(libOn&&libEdit){lib_key(ch);return;}if(cur==8)term_key(ch);else if(cur==9)lapps_key(ch);else if(cur==2&&ned>=0)notes_key(ch);else if(cur==7)browser_key(ch);else if(cur==6&&setpage==2)wifi_key(ch);else if(cur==6&&!setpage&&apned)apn_key(ch);}
static void firstline(const char*s,char*o,int n){int i=0;while(s[i]&&s[i]!='\n'&&i<n-1){o[i]=s[i];i++;}o[i]=0;}
static void notes_dr(void){
 if(ned<0){title("Notes");RR(300,40,40,40,20,ACC(),1);line(312,60,328,60,3,0xFFFFFF,1);line(320,52,320,68,3,0xFFFFFF,1);int n=0;
  for(int i=0;i<NN;i++)if(notes[i][0]){float y=100+n*66;card(16,y,328,58);char l[64];firstline(notes[i],l,40);while(tw(l,17,1)>290&&strlen(l)>1)l[strlen(l)-1]=0;
   T(34,y+10,17,l,INK(),1,0,1);char c[32];sprintf(c,"%d characters",(int)strlen(notes[i]));T(34,y+34,12,c,MUT(),1,0,0);n++;}
  if(!n)T(180,250,16,"No notes yet. Tap + to write one.",MUT(),1,1,0);}
 else{chev(26,54,7,1,ACC(),1);T(40,44,17,"Notes",ACC(),1,0,1);T(340,44,17,"Delete",0xE0453A,1,2,1);card(16,84,328,330);
  float x=30,y=98;const char*p=notes[ned];char ch[8];while(*p){const char*q=p;int c=u8(&p);int L=p-q;memcpy(ch,q,L);ch[L]=0;
   if(c=='\n'){x=30;y+=24;continue;}float w=tw(ch,17,0);if(x+w>330){x=30;y+=24;}if(y>390)break;T(x,y,17,ch,INK(),1,0,0);x+=w;}
  if(fmod(NOW,1.)<.6)RR(x+1,y+1,2,20,1,ACC(),1);}}
static void notes_up(float x,float y,int tap){if(!tap)return;
 if(ned<0){if(in(x,y,300,40,40,40)){for(int i=0;i<NN;i++)if(!notes[i][0]){ned=i;kbWant=1;return;}return;}
  int n=0;for(int i=0;i<NN;i++)if(notes[i][0]){if(in(x,y,16,100+n*66,328,58)){ned=i;kbWant=1;return;}n++;}}
 else{if(in(x,y,10,36,110,34)){ned=-1;kbWant=0;nsave();}else if(in(x,y,270,36,80,34)){notes[ned][0]=0;ned=-1;kbWant=0;nsave();}}}
// --- calendar
static int cy_=-1,cm_;static void cal_dr(void){struct tm n=tmnow();if(cy_<0){cy_=n.tm_year;cm_=n.tm_mon;}
 struct tm t={0};t.tm_year=cy_;t.tm_mon=cm_;t.tm_mday=1;t.tm_hour=12;mktime(&t);int off=(t.tm_wday+6)%7;struct tm e=t;e.tm_mon++;e.tm_mday=0;mktime(&e);int dm=e.tm_mday;
 char b[40];strftime(b,40,"%B %Y",&t);T(20,40,28,b,INK(),1,0,1);chev(280,54,8,1,ACC(),1);chev(330,54,8,2,ACC(),1);
 const char*wd="MTWTFSS";for(int i=0;i<7;i++){char c[2]={wd[i],0};T(40+i*46,110,13,c,MUT(),1,1,1);}
 for(int d=1;d<=dm;d++){int k=off+d-1,cx=40+(k%7)*46,cyy=150+(k/7)*52;int today=cy_==n.tm_year&&cm_==n.tm_mon&&d==n.tm_mday;
  if(today)RR(cx-20,cyy,40,40,20,ACC(),1);sprintf(b,"%d",d);T(cx,cyy+9,17,b,today?0xFFFFFF:INK(),1,1,today);}}
static void cal_up(float x,float y,int tap){if(!tap||y>90)return;if(x>250&&x<305){if(--cm_<0){cm_=11;cy_--;}}else if(x>=305){if(++cm_>11){cm_=0;cy_++;}}}
// --- snake
#define GN 20
static int sx[400],sy[400],sl,sdx,sdy,ndx,ndy,fx,fy,sscore,sbest,sdead;static double stick;static float gx0,gy0;
static void sfood(void){int ok;do{fx=rand()%GN;fy=rand()%GN;ok=1;for(int i=0;i<sl;i++)if(sx[i]==fx&&sy[i]==fy)ok=0;}while(!ok);}
static void sreset(void){sl=3;for(int i=0;i<3;i++){sx[i]=10-i;sy[i]=10;}sdx=ndx=1;sdy=ndy=0;sscore=0;sdead=0;sfood();stick=NOW;}
static void sstep(void){sdx=ndx;sdy=ndy;int hx=(sx[0]+sdx+GN)%GN,hy=(sy[0]+sdy+GN)%GN;for(int i=0;i<sl;i++)if(sx[i]==hx&&sy[i]==hy){sdead=1;if(sscore>sbest)sbest=sscore;return;}
 int g=hx==fx&&hy==fy;if(g&&sl<399)sl++;memmove(sx+1,sx,(sl-1)*sizeof(int));memmove(sy+1,sy,(sl-1)*sizeof(int));sx[0]=hx;sy[0]=hy;if(g){sscore++;sfood();}}
static void snake_dr(void){if(!sl)sreset();while(!sdead&&NOW-stick>.13){stick+=.13;sstep();}
 title("Snake");char b[40];sprintf(b,"%d  best %d",sscore,sbest);T(340,48,17,b,MUT(),1,2,0);RR(20,110,320,320,22,CARD(),1);
 for(int i=sl-1;i>=0;i--)RR(20+sx[i]*16+1,110+sy[i]*16+1,14,14,i?5:7,ACC(),1-i*.6f/(sl+6));RR(20+fx*16+2,110+fy*16+2,12,12,6,0xFF9F0A,1);
 T(180,470,15,sdead?"Game over. Tap to play again.":"Swipe on the board to steer.",MUT(),1,1,0);}
static void snake_dn(float x,float y){gx0=x;gy0=y;}
static void snake_mv(float x,float y){float dx=x-gx0,dy=y-gy0;if(hypotf(dx,dy)<14)return;if(fabsf(dx)>fabsf(dy)){if(sdx==0)ndx=dx>0?1:-1,ndy=0;}else{if(sdy==0)ndy=dy>0?1:-1,ndx=0;}gx0=x;gy0=y;}
static void snake_up(float x,float y,int tap){(void)x;(void)y;if(tap&&sdead)sreset();}
// --- system
static void sys_dr(void){title("System");struct utsname u;uname(&u);struct sysinfo si;sysinfo(&si);struct statvfs sv;statvfs("/",&sv);char v[6][96];
 sprintf(v[0],"%s",u.release);sprintf(v[1],"%dd %dh %dm",(int)(si.uptime/86400),(int)(si.uptime/3600%24),(int)(si.uptime/60%60));
 double tot=si.totalram*(double)si.mem_unit/1048576,fr=si.freeram*(double)si.mem_unit/1048576;sprintf(v[2],"%.0f of %.0f MB used",tot-fr,tot);
 double st=sv.f_blocks*(double)sv.f_frsize/1073741824,sf=sv.f_bavail*(double)sv.f_frsize/1073741824;sprintf(v[3],"%.1f of %.1f GB used",st-sf,st);
 sprintf(v[4],"%d x %d",W,H);sprintf(v[5],"%s",u.machine);const char*k[6]={"Linux kernel","Uptime","Memory","Storage","Display","Architecture"};
 for(int i=0;i<6;i++){float y=96+i*64;card(16,y,328,56);T(34,y+8,12,k[i],MUT(),1,0,0);T(34,y+27,17,v[i],INK(),1,0,0);}
 RR(16,490,328,2,1,LINE(),1);T(180,510,14,"FadanOS 1.0",MUT(),1,1,1);}
// --- settings
static const char*TZN[7]={"Berlin","London","New York","Los Angeles","Tokyo","Sydney","UTC"},*TZV[7]={"Europe/Berlin","Europe/London","America/New_York","America/Los_Angeles","Asia/Tokyo","Australia/Sydney","UTC"};
static void settz(void){setenv("TZ",TZV[S.tz],1);tzset();}
static const int ALS[4]={0,30,60,300};static const char*ALN[4]={"Never","30 seconds","1 minute","5 minutes"};
static const float ASP[3]={.6f,1.f,1.8f};static const char*ANN[3]={"Slow","Normal","Fast"};
static const u32 WC[6][2]={{0xF3F0F7,0xC9B8FF},{0xFFD27D,0xC77DFF},{0xBDE0FF,0x5B7CFA},{0xD4F0A0,0x3FA38F},{0xFFE08A,0xFF9E8A},{0xD5DBE6,0x6B7691}};
static int wlok;static char wcon[40];
static char st_ssid[48],st_ip[64],mm_state[32],mm_op[48],apn[48]="internet";static int st_sig,mm_sig=-1;
static void stat_read(void){const char*pth=getenv("FADAN_STATUS");FILE*f=fopen(pth?pth:"/run/fadan-status","r");st_ssid[0]=st_ip[0]=mm_state[0]=mm_op[0]=0;st_sig=0;mm_sig=-1;if(!f)return;char l[160];
 while(fgets(l,160,f)){l[strcspn(l,"\n")]=0;char*v=strchr(l,'=');if(!v)continue;*v++=0;if(!strcmp(l,"ssid"))snprintf(st_ssid,48,"%s",v);else if(!strcmp(l,"sig"))st_sig=atoi(v);else if(!strcmp(l,"ip"))snprintf(st_ip,64,"%s",v);
  else if(!strcmp(l,"mm_state"))snprintf(mm_state,32,"%s",v);else if(!strcmp(l,"mm_op"))snprintf(mm_op,48,"%s",v);else if(!strcmp(l,"mm_sig")&&v[0])mm_sig=atoi(v);}fclose(f);}
static int wl_if(char*o){const char*fk=getenv("FADAN_FAKEWL");if(fk){snprintf(o,32,"%s",fk);return 1;}DIR*d=opendir("/sys/class/net");struct dirent*e;int ok=0;o[0]=0;if(d){while((e=readdir(d))){char p[300];snprintf(p,300,"/sys/class/net/%s/wireless",e->d_name);if(e->d_name[0]!='.'&&access(p,F_OK)==0){snprintf(o,32,"%s",e->d_name);ok=1;break;}}closedir(d);}return ok;}
static char ifn[32];
static const char*ifname(void){DIR*d;struct dirent*e;ifn[0]=0;if(wl_if(ifn))return ifn;d=opendir("/sys/class/net");if(d){while((e=readdir(d)))if(e->d_name[0]!='.'&&strcmp(e->d_name,"lo")){strncpy(ifn,e->d_name,31);break;}closedir(d);}return ifn;}
static int net_ip(char*o){struct ifaddrs*a,*p;o[0]=0;if(getifaddrs(&a))return 0;for(p=a;p;p=p->ifa_next)if(p->ifa_addr&&p->ifa_addr->sa_family==AF_INET&&strcmp(p->ifa_name,"lo")){inet_ntop(AF_INET,&((struct sockaddr_in*)p->ifa_addr)->sin_addr,o,32);break;}freeifaddrs(a);return o[0]!=0;}
static void net_set(int up){const char*n=ifname();if(!n[0])return;int sk=socket(AF_INET,SOCK_DGRAM,0);struct ifreq r;memset(&r,0,sizeof r);strcpy(r.ifr_name,n);ioctl(sk,SIOCGIFFLAGS,&r);if(up)r.ifr_flags|=IFF_UP;else r.ifr_flags&=~IFF_UP;ioctl(sk,SIOCSIFFLAGS,&r);close(sk);
#ifndef TEST
 if(up)(void)!system("/usr/local/bin/fadan-net >/dev/null 2>&1 &");
#endif
}
static char netsub[48];static double nett=-9;
static char mmsub[64];
static void nettick(void){if(NOW-nett<1.5)return;nett=NOW;stat_read();{char t[32];wlok=wl_if(t);}snprintf(wcon,40,"%s",st_ssid);
 if(S.airplane&&wlok)strcpy(netsub,"Off");else if(st_ssid[0])snprintf(netsub,48,"Connected to %.28s",st_ssid);else if(st_ip[0])snprintf(netsub,48,"Connected, %.36s",st_ip);else strcpy(netsub,"Not connected");
 if(!S.mobile)strcpy(mmsub,"Off");else if(mm_sig>=0)snprintf(mmsub,64,"%s%s%.30s, signal %d%%",strstr(mm_state,"connected")?"Connected, ":"",mm_op[0]?"":"",mm_op[0]?mm_op:mm_state,mm_sig);else snprintf(mmsub,64,"%.40s",mm_state[0]?mm_state:"Starting...");}
static float setsc;static int setH,sld;static float sly;
static int setwalk(float px,float py,int draw){float y=30-setsc;int gi=0;
#define RH 52
#define GSH(h) {gi=0;if(draw)card(16,y,328,(h));}
#define GS(n) GSH((n)*RH)
#define SEP() {if(gi>0&&draw)line(34,y,326,y,1,LINE(),1);gi++;}
#define RT(id,nm,sb,on) {SEP();if(draw){T(34,y+9,16,nm,INK(),1,0,0);T(34,y+30,11,sb,MUT(),1,0,0);sw(286,y+12,on);}else if(in(px,py,16,y,328,RH))return id;y+=RH;}
#define RV(id,nm,val) {SEP();if(draw){T(34,y+16,16,nm,INK(),1,0,0);T(308,y+17,15,val,MUT(),1,2,0);chev(329,y+26,5,2,MUT(),1);}else if(in(px,py,16,y,328,RH))return id;y+=RH;}
#define INFO(nm,sb) {SEP();if(draw){T(34,y+9,16,nm,INK(),1,0,0);T(34,y+30,11,sb,MUT(),1,0,0);}y+=RH;}
#define GE() {y+=16;}
#define LB(t) {if(draw)T(24,y,12,t,MUT(),1,0,1);y+=22;}
 if(draw)T(20,y,34,"Settings",INK(),1,0,1);y+=62;
 LB("APPEARANCE") GSH(5*RH+66)
 RT(1,"Fadan UI",S.fadan?"Accent colour rgb(167, 0, 0)":"Uses the accent colour below",S.fadan)
 RT(2,"Dark appearance","Deep dark theme",S.dark)
 RT(3,"Night shift","Warmer colours for the evening",S.night)
 RT(14,"Blur effects","Real-time background blur",!S.noblur)
 RT(4,"24-hour time","Clock, lock screen, calendar",S.h24)
 {SEP();if(draw){T(34,y+9,16,"Accent colour",INK(),S.fadan?.45f:1,0,0);for(int i=0;i<6;i++){float cx=50+i*46,cy=y+43;if(S.accent==i&&!S.fadan)ring(cx,cy,15,2.2f,ACS[i],1,1);RR(cx-11,cy-11,22,22,11,ACS[i],S.fadan?.35f:1);}}
  else{for(int i=0;i<6;i++)if(in(px,py,32+i*46,y+25,36,36))return 40+i;}y+=66;}
 GE()
 LB("WALLPAPER")
 for(int i=0;i<6;i++){float x=16+(i%3)*112,yy=y+(i/3)*68;if(draw){if(S.wp==i)RR(x-3,yy-3,110,66,19,ACC(),1);RG(x,yy,104,60,16,WC[i][0],WC[i][1],1);}else if(in(px,py,x,yy,104,60))return 20+i;}
 y+=142;
 LB("DISPLAY") GSH(64)
 {if(draw){T(34,y+9,12,"Brightness",MUT(),1,0,0);slider(34,y+42,292,(S.br-30)/70.f);}else if(in(px,py,16,y,328,64))return 30;y+=64;}
 GE()
 LB("NETWORK") GS((wlok?2:1)+1+(mm_state[0]?(S.mobile?2:1):1))
 if(wlok){RT(5,"Wi-Fi",netsub,!S.airplane)RV(11,"Wi-Fi networks",st_ssid[0]&&!S.airplane?st_ssid:"Choose")}else INFO("Wi-Fi","No Wi-Fi hardware found")
 INFO("Connection",st_ip[0]?st_ip:"Offline")
 if(mm_state[0]){RT(12,"Mobile data",mmsub,S.mobile)if(S.mobile){char ab[64];snprintf(ab,64,"%s%s",apn,apned&&fmod(NOW,1.)<.6?"|":"");RV(13,"APN",ab)}}else INFO("Mobile data","No modem or SIM found")
 GE()
 LB("GENERAL") GS(3)
 RV(6,"Auto-lock",ALN[S.autolock]) RV(7,"Animation speed",ANN[S.anim]) RV(8,"Time zone",TZN[S.tz])
 GE()
 if(draw){RR(16,y,158,50,25,CARD(),1);T(95,y+13,16,"Restart",INK(),1,1,1);RR(186,y,158,50,25,0xE0453A,1);T(265,y+13,16,"Power off",0xFFFFFF,1,1,1);}
 else{if(in(px,py,16,y,158,50))return 9;if(in(px,py,186,y,158,50))return 10;}
 y+=66;if(draw)T(180,y,13,"FadanOS 1.0. Linux kernel with a native shell.",MUT(),1,1,0);y+=46;setH=y+setsc;return 0;}
// --- wifi list (settings sub page)
typedef struct{char ssid[40];int sig,sec;}Ap;
static Ap aps[16];static int nap,wfd=-1,wpid,wlen;static char wbuf[60000],wmsg[64],wpass[64],wsel[40];static double wct;
static void wparse(void){nap=0;char*l=wbuf;Ap cur;int have=0;memset(&cur,0,sizeof cur);
#define PUSH() {if(have&&cur.ssid[0]){int k;for(k=0;k<nap;k++)if(!strcmp(aps[k].ssid,cur.ssid))break;if(k==nap&&nap<16)aps[nap++]=cur;else if(k<nap&&cur.sig>aps[k].sig)aps[k]=cur;}}
 while(l&&*l){char*e=strchr(l,'\n');if(e)*e=0;char*t=l;while(*t==' '||*t=='\t')t++;
  if(!strncmp(t,"BSS ",4)){PUSH();memset(&cur,0,sizeof cur);cur.sig=-100;have=1;}
  else if(!strncmp(t,"signal:",7))cur.sig=(int)atof(t+7);
  else if(!strncmp(t,"SSID:",5)){const char*v=t+5;while(*v==' ')v++;snprintf(cur.ssid,40,"%s",v);}
  else if(!strncmp(t,"RSN:",4)||!strncmp(t,"WPA:",4))cur.sec=1;
  l=e?e+1:NULL;}
 PUSH();
 for(int a=1;a<nap;a++){Ap x=aps[a];int b=a-1;while(b>=0&&aps[b].sig<x.sig){aps[b+1]=aps[b];b--;}aps[b+1]=x;}}
static void wscan(void){char ifc[32];
 if(!wl_if(ifc)){nap=0;snprintf(wmsg,64,"No Wi-Fi hardware found");return;}
 if(wfd>=0)return;char cmd[200];snprintf(cmd,200,"ip link set %s up; iw dev %s scan 2>/dev/null",ifc,ifc);
 int pp[2];if(pipe(pp))return;wpid=fork();if(!wpid){int nf=open("/dev/null",O_WRONLY);dup2(pp[1],1);dup2(nf,2);close(pp[0]);close(pp[1]);execl("/bin/sh","sh","-c",cmd,(char*)0);_exit(127);}
 close(pp[1]);fcntl(pp[0],F_SETFL,O_NONBLOCK);wfd=pp[0];wlen=0;snprintf(wmsg,64,"Scanning...");}
static void wpoll(void){if(wfd<0)return;for(int k=0;k<8;k++){int n=read(wfd,wbuf+wlen,sizeof wbuf-1-wlen);if(n>0)wlen+=n;else if(n==0){close(wfd);wfd=-1;waitpid(wpid,0,0);wbuf[wlen]=0;wparse();snprintf(wmsg,64,"%s",nap?"":"No networks found");return;}else break;}}
static void shq(char*o,int n,const char*s){int k=0;o[k++]='\'';for(;*s&&k<n-6;s++){if(*s=='\''){o[k++]='\'';o[k++]='\\';o[k++]='\'';o[k++]='\'';}else if((unsigned char)*s>=32)o[k++]=*s;}o[k++]='\'';o[k]=0;}
static void wconnect(const char*ss,const char*pw){char a[200],b[200],cmd[500];shq(a,200,ss);shq(b,200,pw);snprintf(cmd,500,"/usr/local/bin/fadan-wifi %s %s >/dev/null 2>&1 &",a,b);
#ifndef TEST
 (void)!system(cmd);
#endif
 snprintf(wmsg,64,"Connecting to %.30s...",ss);wct=NOW;S.airplane=0;}
static void wifi_key(int ch){size_t n=strlen(wpass);if(ch==8){if(n)wpass[n-1]=0;}else if(ch==10){if(n>=8){wconnect(wsel,wpass);setpage=1;kbWant=0;}}else if(ch>=32&&n<62){wpass[n]=ch;wpass[n+1]=0;}}
static void wifi_dr(void){wpoll();if(wct>0&&NOW-wct>9){char ip[32];int ok=!strcmp(st_ssid,wsel);(void)ip;snprintf(wmsg,64,"%s",ok?"Connected":"Could not connect");wct=0;nett=-9;}
 chev(26,54,7,1,ACC(),1);T(40,44,17,"Settings",ACC(),1,0,1);if(setpage==1)T(340,44,17,"Scan",ACC(),1,2,1);
 if(setpage==1){T(20,76,28,"Wi-Fi",INK(),1,0,1);if(wmsg[0])T(20,118,13,wmsg,MUT(),1,0,0);
  for(int i=0;i<nap&&i<7;i++){float y=142+i*62;card(16,y,328,54);int con=wcon[0]&&!strcmp(aps[i].ssid,wcon);T(34,y+(con?9:16),16,aps[i].ssid,INK(),1,0,0);if(con)T(34,y+32,11,"Connected",ACC(),1,0,0);int b=aps[i].sig>-55?4:aps[i].sig>-65?3:aps[i].sig>-75?2:1;
   for(int k=0;k<4;k++)RR(304+k*7,y+38-(4+k*4),5,4+k*4,1.5f,k<b?INK():LINE(),1);
   if(aps[i].sec){RR(272,y+24,13,10,2.5f,MUT(),1);ring(278.5f,y+23,3.8f,1.7f,MUT(),1,1);}}}
 else{T(20,76,24,wsel,INK(),1,0,1);T(20,112,13,"Enter the Wi-Fi password",MUT(),1,0,0);RR(16,138,328,48,16,CARD(),1);
  char d[200]="";for(size_t i=0;i<strlen(wpass)&&i<22;i++)strcat(d,"\xE2\x80\xA2");if(fmod(NOW,1.)<.6)strcat(d,"|");T(30,150,18,d,INK(),1,0,0);
  pill(16,200,328,48,ACC(),strlen(wpass)>=8?1:.4f);T(180,213,16,"Connect",0xFFFFFF,1,1,1);}}
static void wifi_up(float x,float y,int tap){if(!tap)return;
 if(y<80&&x<120){if(setpage==2){setpage=1;kbWant=0;}else setpage=0;return;}
 if(setpage==1){if(y<80&&x>260){wscan();return;}for(int i=0;i<nap&&i<7;i++)if(in(x,y,16,142+i*62,328,54)){snprintf(wsel,40,"%s",aps[i].ssid);if(aps[i].sec){setpage=2;wpass[0]=0;kbWant=1;}else wconnect(wsel,"");return;}}
 else if(in(x,y,16,200,328,48)&&strlen(wpass)>=8){wconnect(wsel,wpass);setpage=1;kbWant=0;}}
static void setchg(void){sset();mkwp();}
static void set_dr(void){nettick();if(setpage)wifi_dr();else{setwalk(0,0,1);RR(0,0,360,30,0,BG(),1);}}
static void set_dn(float x,float y){if(setpage)return;sld=setwalk(x,y,0)==30;sly=y;if(sld)S.br=30+CL((x-34)/292.f,0,1)*70;}
static void set_mv(float x,float y){if(setpage)return;if(sld){S.br=30+CL((x-34)/292.f,0,1)*70;return;}setsc=CL(setsc-(y-sly),0,fmaxf(0,setH-600));sly=y;}
static void apn_save(void){FILE*f=fopen(SAVE"/apn","w");if(f){fputs(apn,f);fclose(f);}}
static void apn_key(int ch){size_t n=strlen(apn);if(ch==8){if(n)apn[n-1]=0;}else if(ch==10){apned=0;kbWant=0;apn_save();}else if(ch>32&&ch<127&&n<44){apn[n]=ch;apn[n+1]=0;}}
static void set_up(float x,float y,int tap){if(setpage){wifi_up(x,y,tap);return;}if(sld){sld=0;sset();return;}if(!tap)return;int a=setwalk(x,y,0);if(apned&&a!=13){apned=0;kbWant=0;apn_save();}
 switch(a){case 1:S.fadan^=1;break;case 2:S.dark^=1;break;case 3:S.night^=1;break;case 4:S.h24^=1;break;case 5:if(!wlok)return;S.airplane^=1;net_set(!S.airplane);nett=-9;break;case 12:S.mobile^=1;
#ifndef TEST
 (void)!system(S.mobile?"/usr/local/bin/fadan-mobile on >/dev/null 2>&1 &":"/usr/local/bin/fadan-mobile off >/dev/null 2>&1 &");
#endif
  nett=-9;break;case 13:apned=1;kbWant=1;return;
  case 6:S.autolock=(S.autolock+1)%4;break;case 7:S.anim=(S.anim+1)%3;break;case 8:S.tz=(S.tz+1)%7;settz();break;
  case 11:if(!wlok)return;setpage=1;wscan();return;case 14:S.noblur^=1;break;case 9:doreboot(RB_AUTOBOOT);return;case 10:doreboot(RB_POWER_OFF);return;default:if(a>=20&&a<26)S.wp=a-20;else if(a>=40&&a<46)S.accent=a-40;else return;}
 setchg();}
// --- browser (text mode: no JavaScript, no images)
#define BU 512
typedef struct{char*t;short sz,link;char bold,brk,glue;float x,y,w;}Wd;
static Wd*bw;static int nbw,bcap,bfd=-1,bpid,bedit,nbl,nbh;static char*bh;static size_t blen,bcp;
static char burl[BU],bcur[BU],btitle[96],blk[250][BU],bhist[16][BU];static float bsc,bmax,bsy;static double bt0;
static const char*BQ[6][2]={{"Wikipedia","https://en.m.wikipedia.org"},{"DuckDuckGo","https://html.duckduckgo.com/html/"},{"Hacker News","https://news.ycombinator.com"},{"NPR Text","https://text.npr.org"},{"Example","https://example.com"},{"Kernel.org","https://www.kernel.org"}};
static void bfree(void){for(int i=0;i<nbw;i++)free(bw[i].t);nbw=0;nbl=0;btitle[0]=0;}
static int bglue;
static void badd(const char*t,int len,int sz,int bold,int link,int brk){if(nbw>=40000)return;if(nbw>=bcap){bcap=bcap?bcap*2:1024;bw=realloc(bw,bcap*sizeof(Wd));}Wd*w=&bw[nbw++];w->t=strndup(t,len);w->sz=sz;w->bold=bold;w->link=link;w->brk=brk;w->glue=bglue;bglue=0;}
static int enc(int c,char*o){if(c<128){o[0]=c;return 1;}if(c<0x800){o[0]=0xC0|c>>6;o[1]=0x80|(c&63);return 2;}o[0]=0xE0|c>>12;o[1]=0x80|(c>>6&63);o[2]=0x80|(c&63);return 3;}
static int ent(const char*s,int*adv){static const struct{const char*n;int c;}E[]={{"amp",'&'},{"lt",'<'},{"gt",'>'},{"quot",'"'},{"apos",'\''},{"nbsp",0xA0},{"hellip",0x2026},{"mdash",0x2014},{"ndash",0x2013},{"copy",0xA9},{"laquo",0xAB},{"raquo",0xBB},{"middot",0xB7},{"rsquo",0x2019},{"lsquo",0x2018},{"rdquo",0x201D},{"ldquo",0x201C},{"bull",0x2022}};
 const char*e=strchr(s,';');if(!e||e-s>10)return 0;*adv=e-s+1;if(s[1]=='#'){int c=s[2]=='x'||s[2]=='X'?(int)strtol(s+3,0,16):atoi(s+2);return c>0?c:0;}
 for(unsigned i=0;i<sizeof E/sizeof*E;i++)if(strlen(E[i].n)==(size_t)(e-s-1)&&!strncmp(s+1,E[i].n,e-s-1))return E[i].c;return 0;}
static int lc(const char*s,const char*t){return !strncasecmp(s,t,strlen(t));}
static int attr(const char*tg,const char*e,const char*nm,char*o,int n){size_t L=strlen(nm);for(const char*p=tg;p<e;p++){if(isspace((unsigned char)p[-1])&&!strncasecmp(p,nm,L)&&p[L]=='='){p+=L+1;char q=*p=='"'||*p=='\''?*p++:0;int k=0;while(p<e&&k<n-1&&(q?*p!=q:!isspace((unsigned char)*p)))o[k++]=*p++;o[k]=0;return 1;}}return 0;}
static void urldec(char*s){char*o=s;while(*s){if(*s=='%'&&isxdigit((unsigned char)s[1])&&isxdigit((unsigned char)s[2])){char h[3]={s[1],s[2],0};*o++=strtol(h,0,16);s+=3;}else if(*s=='&')break;else *o++=*s++;}*o=0;}
static void resolve(const char*base,const char*h,char*o){o[0]=0;if(!h[0]||h[0]=='#'||lc(h,"javascript")||lc(h,"mailto")||lc(h,"tel:"))return;
 if(lc(h,"http")){snprintf(o,BU,"%s",h);}else if(h[0]=='/'&&h[1]=='/'){snprintf(o,BU,"https:%s",h);}
 else{char root[BU];snprintf(root,BU,"%s",base);char*sch=strstr(root,"://");char*p=sch?strchr(sch+3,'/'):NULL;
  if(h[0]=='/'){if(p)*p=0;snprintf(o,BU,"%s%s",root,h);}else{char*q=p?strrchr(root,'/'):NULL;if(!p)snprintf(o,BU,"%s/%s",root,h);else{q[1]=0;snprintf(o,BU,"%s%s",root,h);}}}
 char*u=strstr(o,"uddg=");if(u){char t[BU];snprintf(t,BU,"%s",u+5);urldec(t);snprintf(o,BU,"%s",t);}}
static void bparse(void){bfree();if(!bh)return;char*p=bh;int sz=15,bold=0,link=-1,brk=0,pre=0,intit=0,sp=1;char w[256];int wl=0;
#define FL() {if(wl){bglue=!sp&&!brk;badd(w,wl,sz,bold,link,brk);sp=0;brk=0;wl=0;}}
 while(*p){
  if(*p=='<'){if(!strncmp(p,"<!--",4)){char*e=strstr(p,"-->");p=e?e+3:p+strlen(p);continue;}
   char*e=strchr(p,'>');if(!e)break;char*tg=p+1;int cl=0;if(*tg=='/'){cl=1;tg++;}
   if(!cl&&(lc(tg,"script")||lc(tg,"style")||lc(tg,"noscript")||lc(tg,"svg"))){FL();char nm[20]="</";int n=2;for(char*q=tg;isalpha((unsigned char)*q)&&n<16;q++)nm[n++]=*q;nm[n]=0;char*c=strcasestr(e,nm);if(!c){p+=strlen(p);break;}char*ce=strchr(c,'>');p=ce?ce+1:c+strlen(c);continue;}
   FL();
   if(lc(tg,"title"))intit=!cl;
   else if(lc(tg,"br"))brk=brk<1?1:brk;
   else if(lc(tg,"hr")){badd("\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80\xE2\x94\x80",24,sz,0,-1,1);brk=1;}
   else if(tg[0]=='h'&&tg[1]>='1'&&tg[1]<='6'&&!isalpha((unsigned char)tg[2])){if(cl){sz=15;bold=0;}else{sz=tg[1]=='1'?22:tg[1]=='2'?19:16;bold=1;}brk=2;}
   else if(lc(tg,"li")&&!isalpha((unsigned char)tg[2])){if(!cl){brk=brk<1?1:brk;badd("\xE2\x80\xA2",3,sz,0,-1,brk);brk=0;}}
   else if(lc(tg,"a")&&!isalpha((unsigned char)tg[1])){if(cl)link=-1;else{char hr[BU];link=-1;if(attr(tg,e,"href",hr,BU)&&nbl<250){resolve(bcur,hr,blk[nbl]);if(blk[nbl][0])link=nbl++;}}}
   else if((lc(tg,"b")&&!isalpha((unsigned char)tg[1]))||lc(tg,"strong"))bold=!cl;
   else if(lc(tg,"pre")){pre=!cl;brk=2;}
   else if(lc(tg,"img")){char al[80];if(attr(tg,e,"alt",al,80)&&al[0]){char b2[90];snprintf(b2,90,"[%s]",al);badd(b2,strlen(b2),sz,0,link,brk);brk=0;}}
   else if(lc(tg,"p")&&!isalpha((unsigned char)tg[1]))brk=2;
   else if(lc(tg,"div")||lc(tg,"section")||lc(tg,"article")||lc(tg,"ul")||lc(tg,"ol")||lc(tg,"table")||lc(tg,"tr")||lc(tg,"blockquote")||lc(tg,"header")||lc(tg,"footer")||lc(tg,"form")||lc(tg,"nav")||lc(tg,"main")||lc(tg,"dd")||lc(tg,"dt"))brk=brk<1?1:brk;
   p=e+1;continue;}
  if(intit){size_t n=strlen(btitle);if(n<90&&*p!='\n')btitle[n]=*p,btitle[n+1]=0;p++;continue;}
  if(isspace((unsigned char)*p)){FL();sp=1;if(pre&&*p=='\n')brk=brk<1?1:brk;p++;continue;}
  if(*p=='&'){int adv=0;int c=ent(p,&adv);if(c){char u[5];int n=enc(c,u);if(c==0xA0){FL();}else{if(wl+n>250){FL();}memcpy(w+wl,u,n);wl+=n;}p+=adv;continue;}}
  if(wl>=250)FL();w[wl++]=*p++;}
 FL();}
static void blayout(void){float x=16,y=0,lh=21;int first=1;
 for(int i=0;i<nbw;i++){Wd*w=&bw[i];float ww=tws(w->t,w->sz*2,w->bold)/2.f,h=w->sz*1.42f,sp=w->sz*.3f;int nl=w->brk||(x>16&&x+(w->glue?0:sp)+ww>344);
  if(first){first=0;lh=h;}else if(nl){y+=lh+(w->brk>1?9:0);x=16;lh=h;}else{if(x>16&&!w->glue)x+=sp;if(h>lh)lh=h;}
  w->x=x;w->y=y;w->w=ww;x+=ww;}
 bmax=y+lh+60;}
static void bfinish(void){bh[blen]=0;char*m=NULL,*q=bh;while((q=strstr(q,"<!--FADAN-URL:")))m=q++;
 if(m){char*e=strstr(m,"-->");if(e&&e-m-14<BU){memcpy(bcur,m+14,e-m-14);bcur[e-m-14]=0;}*m=0;blen=m-bh;}
 if(blen<5){const char*er="<h2>Could not load the page</h2><p>Check that Wi-Fi is on in Settings, and that the address is right.</p>";strcpy(bh,er);blen=strlen(er);}
 bparse();blayout();bsc=0;}
static void bstop(void){if(bfd>=0){close(bfd);kill(bpid,SIGKILL);waitpid(bpid,0,0);bfd=-1;}}
static void bgo(const char*in_,int push){char u[BU],cmd[BU*2+300];while(*in_==' ')in_++;if(!*in_)return;
 if(strstr(in_,"://"))snprintf(u,BU,"%s",in_);else if(strchr(in_,' ')||!strchr(in_,'.')){char q[BU];int k=0;for(const char*c=in_;*c&&k<BU-40;c++){if(isalnum((unsigned char)*c))q[k++]=*c;else k+=snprintf(q+k,8,"%%%02X",(unsigned char)*c);}q[k]=0;snprintf(u,BU,"https://html.duckduckgo.com/html/?q=%s",q);}
 else snprintf(u,BU,"https://%s",in_);
 char s[BU];int k=0;for(char*c=u;*c&&k<BU-4;c++){if(*c=='\'')k+=snprintf(s+k,4,"%%27");else if((unsigned char)*c>=32)s[k++]=*c;}s[k]=0;
 if(push&&bcur[0]){if(nbh>=16){memmove(bhist[0],bhist[1],15*BU);nbh=15;}strcpy(bhist[nbh++],bcur);}
 bstop();snprintf(bcur,BU,"%s",s);bedit=0;kbWant=0;
#ifdef TEST
 snprintf(cmd,sizeof cmd,"cat /tmp/page.html; echo '<!--FADAN-URL:%s-->'",s);
#else
 snprintf(cmd,sizeof cmd,"curl -sL --max-time 25 --max-filesize 3000000 --compressed -A 'Mozilla/5.0 (X11; Linux x86_64; FadanOS) Gecko/20100101 Firefox/120.0' -H 'Accept-Language: en' -w '\\n<!--FADAN-URL:%%{url_effective}-->' '%s'",s);
#endif
 int pp[2];if(pipe(pp))return;bpid=fork();if(!bpid){int nf=open("/dev/null",O_WRONLY);dup2(pp[1],1);dup2(nf,2);close(pp[0]);close(pp[1]);execl("/bin/sh","sh","-c",cmd,(char*)0);_exit(127);}
 close(pp[1]);fcntl(pp[0],F_SETFL,O_NONBLOCK);bfd=pp[0];blen=0;if(!bh){bcp=65536;bh=malloc(bcp);}bt0=NOW;bfree();bsc=0;}
static void bpoll(void){if(bfd<0)return;char tmp[16384];for(int k=0;k<8;k++){int n=read(bfd,tmp,sizeof tmp);
 if(n>0){if(blen+n+2>bcp){bcp=(blen+n+2)*2;bh=realloc(bh,bcp);}memcpy(bh+blen,tmp,n);blen+=n;}
 else if(n==0){close(bfd);bfd=-1;waitpid(bpid,0,0);bfinish();return;}else break;}}
static void browser_key(int ch){if(!bedit)return;size_t n=strlen(burl);if(ch==8){if(n)burl[n-1]=0;}else if(ch==10){bedit=0;kbWant=0;bgo(burl,1);}else if(ch>=32&&n<BU-2){burl[n]=ch;burl[n+1]=0;}}
static void br_dr(void){bpoll();
 if(!bcur[0]){T(20,100,24,"Browser",INK(),1,0,1);T(20,134,13,"Text mode: no JavaScript or images.",MUT(),1,0,0);
  for(int i=0;i<6;i++){float x=16+(i%2)*168,y=170+(i/2)*84;card(x,y,160,72);T(x+14,y+14,16,BQ[i][0],INK(),1,0,1);T(x+14,y+40,11,BQ[i][1]+8,MUT(),1,0,0);}}
 else{for(int i=0;i<nbw;i++){Wd*w=&bw[i];float y=92+w->y-bsc;if(y<70||y>630)continue;u32 c=w->link>=0?ACC():INK();T(w->x,y,w->sz,w->t,c,1,0,w->bold);if(w->link>=0)line(w->x,y+w->sz*1.22f,w->x+w->w,y+w->sz*1.22f,1,c,.45f);}
  if(bfd>=0&&!nbw)T(180,300,15,"Loading...",MUT(),1,1,0);}
 RR(0,0,360,88,0,BG(),1);chev(26,60,7,1,nbh||bcur[0]?ACC():MUT(),1);RR(44,44,262,32,16,CARD(),1);
 char b[BU];if(bedit){snprintf(b,BU,"%s%s",burl,fmod(NOW,1.)<.6?"|":"");if(!burl[0])snprintf(b,BU,"%s","Search or enter address");}
 else if(bcur[0])snprintf(b,BU,"%s",btitle[0]?btitle:bcur+(strstr(bcur,"://")?(strstr(bcur,"://")-bcur+3):0));else snprintf(b,BU,"Search or enter address");
 while(tw(b,14,0)>236&&strlen(b)>3){if(bedit){memmove(b,b+1,strlen(b));}else b[strlen(b)-1]=0;}
 T(58,52,14,b,bedit&&burl[0]?INK():(bcur[0]?INK():MUT()),1,0,0);
 if(bfd>=0){line(324,52,338,66,2.4f,ACC(),1);line(338,52,324,66,2.4f,ACC(),1);RR(0,86,360*(1-expf(-(float)(NOW-bt0)/3)),2,1,ACC(),1);}
 else if(bcur[0]){ring(331,60,7,2.4f,ACC(),1,.8f);tri(334,50,340,56,331,57,ACC(),1);}}
static void br_dn(float x,float y){(void)x;bsy=y;}
static void br_mv(float x,float y){(void)x;if(!bcur[0])return;bsc=CL(bsc-(y-bsy),0,fmaxf(0,bmax-520));bsy=y;}
static void br_up(float x,float y,int tap){if(!tap)return;
 if(y<88){if(x<40){if(nbh)bgo(bhist[--nbh],0);else if(bcur[0]){bstop();bcur[0]=0;bfree();}}
  else if(x>312){if(bfd>=0)bstop();else if(bcur[0]){char t[BU];snprintf(t,BU,"%s",bcur);bgo(t,0);}}
  else if(y>40){bedit=1;kbWant=1;burl[0]=0;}return;}
 if(bedit){bedit=0;kbWant=0;}
 if(!bcur[0]){for(int i=0;i<6;i++)if(in(x,y,16+(i%2)*168,170+(i/2)*84,160,72)){bgo(BQ[i][1],1);return;}return;}
 for(int i=0;i<nbw;i++){Wd*w=&bw[i];if(w->link<0)continue;float wy=92+w->y-bsc;if(in(x,y,w->x-3,wy-2,w->w+6,w->sz*1.5f)){bgo(blk[(int)w->link],1);return;}}}
// --- terminal (real shell on a pty, VT100/ANSI subset)
#define TC 48
#define TR 24
typedef struct{int ch;short fg,bg;char at;}Cell;
static Cell tg[TR][TC],tgs[TR][TC];static int tcx,tcy,ttop=0,tbot=TR-1,tsx,tsy,tvis=1,tst,tp[8],tnp,tpriv,tutf,tutn,tctrl,talt,tmfd=-1,tpid,tfg=256,tbg=257,tat;static char tpend[300];
static void tclr(int r0,int c0,int r1,int c1){for(int r=r0;r<=r1;r++)for(int c=(r==r0?c0:0);c<=(r==r1?c1:TC-1);c++){tg[r][c].ch=' ';tg[r][c].fg=256;tg[r][c].bg=tbg;tg[r][c].at=0;}}
static void tscroll(int up){if(up){memmove(tg[ttop],tg[ttop+1],(tbot-ttop)*sizeof tg[0]);tclr(tbot,0,tbot,TC-1);}else{memmove(tg[ttop+1],tg[ttop],(tbot-ttop)*sizeof tg[0]);tclr(ttop,0,ttop,TC-1);}}
static void tlf(void){if(tcy==tbot)tscroll(1);else if(tcy<TR-1)tcy++;}
static void tput(int ch){if(tcx>=TC){tcx=0;tlf();}tg[tcy][tcx].ch=ch;tg[tcy][tcx].fg=tfg;tg[tcy][tcx].bg=tbg;tg[tcy][tcx].at=tat;tcx++;}
static void twr(const char*b,int n){if(tmfd>=0)(void)!write(tmfd,b,n);}
static void tsgr(void){for(int i=0;i<tnp;i++){int v=tp[i];
 if(v==0){tfg=256;tbg=257;tat=0;}else if(v==1)tat|=1;else if(v==4)tat|=2;else if(v==7)tat|=4;else if(v==22)tat&=~1;else if(v==24)tat&=~2;else if(v==27)tat&=~4;
 else if(v>=30&&v<=37)tfg=v-30;else if(v>=40&&v<=47)tbg=v-40;else if(v>=90&&v<=97)tfg=v-82;else if(v>=100&&v<=107)tbg=v-92;else if(v==39)tfg=256;else if(v==49)tbg=257;
 else if((v==38||v==48)&&i+1<tnp){int c=-1;if(tp[i+1]==5&&i+2<tnp){c=tp[i+2];i+=2;}else if(tp[i+1]==2&&i+4<tnp){c=16+36*(tp[i+2]*5/255)+6*(tp[i+3]*5/255)+(tp[i+4]*5/255);i+=4;}if(c>=0){if(v==38)tfg=c;else tbg=c;}}}}
static void tcsi(int f){int a=tp[0],b=tnp>1?tp[1]:0,n=a?a:1;
 if(tpriv){if(f=='h'||f=='l'){int on=f=='h';for(int i=0;i<tnp;i++){if(tp[i]==25)tvis=on;else if(tp[i]==1049||tp[i]==47||tp[i]==1047){if(on&&!talt){memcpy(tgs,tg,sizeof tg);talt=1;tclr(0,0,TR-1,TC-1);tcx=tcy=0;}else if(!on&&talt){memcpy(tg,tgs,sizeof tg);talt=0;}}}}return;}
 switch(f){case 'A':tcy=CL(tcy-n,0,TR-1);break;case 'B':tcy=CL(tcy+n,0,TR-1);break;case 'C':tcx=CL(tcx+n,0,TC-1);break;case 'D':tcx=CL(tcx-n,0,TC-1);break;
  case 'E':tcy=CL(tcy+n,0,TR-1);tcx=0;break;case 'F':tcy=CL(tcy-n,0,TR-1);tcx=0;break;case 'G':tcx=CL(n-1,0,TC-1);break;case 'd':tcy=CL(n-1,0,TR-1);break;
  case 'H':case 'f':tcy=CL((a?a:1)-1,0,TR-1);tcx=CL((b?b:1)-1,0,TC-1);break;
  case 'J':if(a==0){tclr(tcy,tcx,tcy,TC-1);if(tcy<TR-1)tclr(tcy+1,0,TR-1,TC-1);}else if(a==1){if(tcy>0)tclr(0,0,tcy-1,TC-1);tclr(tcy,0,tcy,tcx);}else tclr(0,0,TR-1,TC-1);break;
  case 'K':if(a==0)tclr(tcy,tcx,tcy,TC-1);else if(a==1)tclr(tcy,0,tcy,tcx);else tclr(tcy,0,tcy,TC-1);break;
  case 'L':for(int i=0;i<n;i++){int t=ttop;ttop=tcy;tscroll(0);ttop=t;}break;case 'M':for(int i=0;i<n;i++){int t=ttop;ttop=tcy;tscroll(1);ttop=t;}break;
  case '@':for(int i=0;i<n&&tcx<TC-1;i++){memmove(&tg[tcy][tcx+1],&tg[tcy][tcx],(TC-tcx-1)*sizeof(Cell));tclr(tcy,tcx,tcy,tcx);}break;
  case 'P':for(int i=0;i<n&&tcx<TC-1;i++){memmove(&tg[tcy][tcx],&tg[tcy][tcx+1],(TC-tcx-1)*sizeof(Cell));tclr(tcy,TC-1,tcy,TC-1);}break;
  case 'X':for(int i=0;i<n&&tcx+i<TC;i++)tclr(tcy,tcx+i,tcy,tcx+i);break;
  case 'S':for(int i=0;i<n;i++)tscroll(1);break;case 'T':for(int i=0;i<n;i++)tscroll(0);break;
  case 'm':tsgr();break;case 'r':ttop=CL((a?a:1)-1,0,TR-1);tbot=CL((b?b:TR)-1,0,TR-1);if(tbot<ttop){ttop=0;tbot=TR-1;}tcx=0;tcy=0;break;
  case 's':tsx=tcx;tsy=tcy;break;case 'u':tcx=tsx;tcy=tsy;break;
  case 'n':if(a==6){char r[24];int l=snprintf(r,24,"\033[%d;%dR",tcy+1,tcx+1);twr(r,l);}break;}}
static void tbyte(unsigned char c){
 if(tst==0){if(c==27){tst=1;return;}
  if(c>=0x80){if(c>=0xC0){tutn=c>=0xF0?3:c>=0xE0?2:1;tutf=c&(0x3F>>tutn);}else if(tutn){tutf=tutf<<6|(c&63);if(--tutn==0)tput(tutf);}return;}
  if(c=='\n'||c==11||c==12){tlf();return;}if(c=='\r'){tcx=0;return;}if(c==8){if(tcx>0)tcx--;return;}if(c=='\t'){tcx=fminf(TC-1,(tcx/8+1)*8);return;}if(c<32)return;tput(c);return;}
 if(tst==1){tst=0;if(c=='['){tst=2;tnp=0;tpriv=0;memset(tp,0,sizeof tp);}else if(c==']')tst=3;else if(c=='('||c==')')tst=4;else if(c=='7'){tsx=tcx;tsy=tcy;}else if(c=='8'){tcx=tsx;tcy=tsy;}
  else if(c=='M'){if(tcy==ttop)tscroll(0);else if(tcy>0)tcy--;}else if(c=='D')tlf();else if(c=='E'){tcx=0;tlf();}else if(c=='c'){tfg=256;tbg=257;tat=0;ttop=0;tbot=TR-1;tclr(0,0,TR-1,TC-1);tcx=tcy=0;}return;}
 if(tst==4){tst=0;return;}if(tst==3){if(c==7)tst=0;else if(c==27)tst=5;return;}if(tst==5){tst=0;return;}
 if(c=='?'){tpriv=1;return;}if(c>='0'&&c<='9'){if(!tnp)tnp=1;tp[tnp-1]=tp[tnp-1]*10+c-'0';return;}if(c==';'){if(!tnp)tnp=1;if(tnp<8)tnp++;return;}
 if(c>=0x40&&c<=0x7E){if(!tnp)tnp=1;tcsi(c);tst=0;}}
static void tstart(void){if(tmfd>=0)return;int m=posix_openpt(O_RDWR|O_NOCTTY);if(m<0)return;grantpt(m);unlockpt(m);char*sn=ptsname(m);struct winsize ws={TR,TC,0,0};ioctl(m,TIOCSWINSZ,&ws);
 tpid=fork();if(!tpid){setsid();int sl=open(sn,O_RDWR);ioctl(sl,TIOCSCTTY,0);dup2(sl,0);dup2(sl,1);dup2(sl,2);if(sl>2)close(sl);close(m);setenv("TERM","linux",1);setenv("HOME","/root",1);setenv("LANG","C.UTF-8",1);
  setenv("PATH","/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",1);{const char*sh=access("/bin/bash",X_OK)==0?"/bin/bash":"/bin/sh";execl(sh,sh,"-l",(char*)0);}_exit(127);}
 fcntl(m,F_SETFL,O_NONBLOCK);tmfd=m;tfg=256;tbg=257;tat=0;ttop=0;tbot=TR-1;tclr(0,0,TR-1,TC-1);tcx=tcy=0;}
static void term_poll(void){if(tmfd<0)return;unsigned char b[4096];for(int k=0;k<6;k++){int n=read(tmfd,b,sizeof b);if(n>0){for(int i=0;i<n;i++)tbyte(b[i]);slow=1;}else{if(n<0&&errno==EAGAIN)break;close(tmfd);tmfd=-1;waitpid(tpid,0,0);if(cur==8)tstart();break;}}}
static void term_key(int ch){char o[8];int n=0;if(ch>=0x101&&ch<=0x104){static const char*A[4]={"\033[A","\033[B","\033[D","\033[C"};twr(A[ch-0x101],3);return;}
 if(ch==8)o[n++]=127;else if(ch==10)o[n++]='\r';else if(tctrl&&((ch>='a'&&ch<='z')||ch=='['||ch=='\\'||ch==']')){o[n++]=ch=='['?27:ch&31;tctrl=0;}else if(ch<128)o[n++]=ch;if(n)twr(o,n);}
static u32 pal(int i){static const u32 L[16]={0x1D1D20,0xC0392B,0x1E8E3E,0xB7791F,0x2563EB,0x9B3BB5,0x0E7490,0x8A8F98,0x6B7280,0xE0453A,0x16A34A,0xD69E2E,0x3B82F6,0xA855F7,0x06B6D4,0x4B5563},
 D[16]={0x555560,0xFF6B60,0x4ADE80,0xFBBF24,0x60A5FA,0xC084FC,0x22D3EE,0xD1D5DB,0x6B7280,0xFF8A80,0x86EFAC,0xFDE68A,0x93C5FD,0xD8B4FE,0x67E8F9,0xFFFFFF};
 if(i<16)return S.dark?D[i]:L[i];if(i<232){int k=i-16,r=k/36,g=k/6%6,b=k%6;return (u32)((r?r*40+55:0)<<16|(g?g*40+55:0)<<8|(b?b*40+55:0));}int v=8+(i-232)*10;return v<<16|v<<8|v;}
static u32 tcol(int c){return c==256?INK():c==257?CARD():pal(c);}
static void term_dr(void){term_poll();RR(8,38,344,TR*14.5f+8,14,CARD(),1);float tch=14.5f,x0=12,y0=42;int ds=(int)(12*X.s*SC+.5f);float tcw=ds>3?glyph('M',ds,4)->adv/(X.s*SC):7.2f;
 for(int r=0;r<TR;r++){int c=0;while(c<TC){Cell*k=&tg[r][c];int j=c,n=0,allsp=1;char b[TC*3+4];while(j<TC&&tg[r][j].fg==k->fg&&tg[r][j].bg==k->bg&&tg[r][j].at==k->at){int ch=tg[r][j].ch?tg[r][j].ch:' ';if(ch!=' ')allsp=0;n+=enc(ch,b+n);j++;}b[n]=0;
  int fg=k->fg,bg=k->bg;if((k->at&1)&&fg<8)fg+=8;u32 fc=tcol(fg),bc=tcol(bg);if(k->at&4){u32 t=fc;fc=bc;bc=t;if(k->bg==257)bc=INK();if(k->fg==256)fc=CARD();}
  int dbg=(bg!=257)||(k->at&4);if(dbg)RR(x0+c*tcw,y0+r*tch,(j-c)*tcw+.5f,tch,0,bc,1);if(!allsp)T(x0+c*tcw,y0+r*tch,12,b,fc,1,0,4);if(k->at&2)line(x0+c*tcw,y0+r*tch+13,x0+j*tcw,y0+r*tch+13,1,fc,1);c=j;}}
 if(tvis&&fmod(NOW,1.)<.7)RR(x0+tcx*tcw,y0+tcy*tch,tcw,tch,2,ACC(),.6f);
 const char*kn[3]={"Esc","Tab","Ctrl"};for(int i=0;i<7;i++){float x=8+i*50;RR(x,396,46,32,10,i==2&&tctrl?ACC():CARD(),1);u32 c=i==2&&tctrl?0xFFFFFF:INK();
  if(i<3)T(x+23,404,13,kn[i],c,1,1,1);else if(i==3)chev(x+23,412,6,1,c,1);else if(i==6)chev(x+23,412,6,2,c,1);else chev(x+23,i==4?410:414,6,i==4?3:0,c,1);}}
static void term_up(float x,float y,int tap){if(!tap)return;
 if(y>=396&&y<430){int i=(int)((x-8)/50);if(i<0||i>6||x-8-i*50>46)return;if(i==0)term_key(27);else if(i==1)term_key(9);else if(i==2)tctrl^=1;else{static const int K[4]={0x103,0x102,0x101,0x104};term_key(K[i-3]);}return;}
 kbWant=!kbWant;}
// --- Linux apps (installs real packages from the Alpine repository)
typedef struct{const char*n,*bin,*pkg,*d;}Pk;
static const Pk PK[10]={{"nano","nano","nano","Simple text editor"},{"Vim","vim","vim","Powerful text editor"},{"micro","micro","micro","Modern terminal editor"},{"htop","htop","htop","Process viewer"},{"Midnight Commander","mc","mc","File manager"},{"Python 3","python3","python3","Python interpreter"},{"Git","git","git","Version control"},{"Lynx","lynx","lynx","Text web browser"},{"ncdu","ncdu","ncdu","Disk usage viewer"},{"Node.js","node","nodejs","JavaScript runtime"}};
#define ND 64
typedef struct{char name[40],cmd[240];char term,seen,valid,custom;}DA;static DA da[ND];
static int pkinst(const char*bin){static const char*d[3]={"/usr/bin/","/bin/","/usr/local/bin/"};char p[160];for(int i=0;i<3;i++){snprintf(p,160,"%s%s",d[i],bin);if(access(p,X_OK)==0)return 1;}return 0;}
static int launch=-1,lined;static char lpk[64];static float lsc,lsy;static int lins[10];static double lit=-9;
static void launchTerm(const char*cmd){snprintf(tpend,300,"t=$(date +%%s); fadan-net >/dev/null 2>&1; %s; echo \"Done in $(($(date +%%s)-t)) s\"",cmd);closeApp();launch=8;}
static void lapps_key(int ch){if(!lined)return;size_t n=strlen(lpk);if(ch==8){if(n)lpk[n-1]=0;}else if(ch==10){lined=0;kbWant=0;}else if(n<60&&ch<128&&(isalnum(ch)||ch=='-'||ch=='.'||ch=='_'||ch=='+'||ch=='/')){lpk[n]=ch;lpk[n+1]=0;}}
static void lapps_dr(void){if(NOW-lit>1.5){lit=NOW;for(int i=0;i<10;i++)lins[i]=pkinst(PK[i].bin);}
 float y=150-lsc;for(int i=0;i<10;i++,y+=70){if(y<30||y>630)continue;card(16,y,328,62);T(32,y+9,16,PK[i].n,INK(),1,0,1);T(32,y+34,12,lins[i]?"Installed":PK[i].d,lins[i]?ACC():MUT(),1,0,0);
  RR(268,y+10,68,32,16,lins[i]?ACC():(S.dark?0x3A3A42:0xE9E7E8),1);T(302,y+17,14,lins[i]?"Open":"Install",lins[i]?0xFFFFFF:INK(),1,1,1);if(lins[i])T(302,y+45,10,"Remove",MUT(),1,1,0);}
 RR(0,0,360,150,0,BG(),1);title("Linux Apps");T(20,76,12,"Real Linux programs from the Alpine repository.",MUT(),1,0,0);
 RR(16,100,240,44,14,CARD(),1);char b[80];snprintf(b,80,"%s%s",lpk,lined&&fmod(NOW,1.)<.6?"|":"");T(30,113,14,lpk[0]||lined?b:"Package or .apk file",lpk[0]||lined?INK():MUT(),1,0,0);
 pill(264,100,80,44,ACC(),lpk[0]?1:.4f);T(304,113,14,"Install",0xFFFFFF,1,1,1);}
static void lapps_dn(float x,float y){(void)x;lsy=y;}
static void lapps_mv(float x,float y){(void)x;lsc=CL(lsc-(y-lsy),0,fmaxf(0,150+700-560));lsy=y;}
static void lapps_up(float x,float y,int tap){if(!tap)return;char c[200];
 if(y<150){if(in(x,y,264,100,80,44)&&lpk[0]){if(strstr(lpk,".apk"))snprintf(c,200,"apk add --allow-untrusted %s",lpk);else{snprintf(c,200,"apk add --cache-max-age 100000 %s",lpk);FILE*cf=fopen(SAVE"/custom-pkgs.txt","a");if(cf){fprintf(cf,"%s\n",lpk);fclose(cf);}}lined=0;kbWant=0;launchTerm(c);lpk[0]=0;}else if(in(x,y,16,100,240,44)){lined=1;kbWant=1;}return;}
 lined=0;kbWant=0;for(int i=0;i<10;i++){float yy=150-lsc+i*70;if(!in(x,y,262,yy+4,80,58))continue;
  if(!lins[i]){snprintf(c,200,"apk add --cache-max-age 100000 %s",PK[i].pkg);launchTerm(c);}
  else if(y>yy+42){snprintf(c,200,"apk del %s",PK[i].pkg);launchTerm(c);}else launchTerm(PK[i].bin);return;}}
static void nodn(float x,float y){(void)x;(void)y;}
static void init_apps(void){
 apps[0]=(App){"Clock",0xFFB066,0xFF6A3D,clock_dr,nodn,nodn,clock_up,1};apps[1]=(App){"Calculator",0xA6A6B0,0x62626B,calc_dr,calc_dn,nodn,calc_up,0};
 apps[2]=(App){"Notes",0xFFE066,0xFFB300,notes_dr,nodn,nodn,notes_up,1};apps[3]=(App){"Calendar",0xFF7A7A,0xD93A3A,cal_dr,nodn,nodn,cal_up,0};
 apps[4]=(App){"Snake",0x7BE495,0x2FA75B,snake_dr,snake_dn,snake_mv,snake_up,1};apps[5]=(App){"System",0x8FB7FF,0x4A6FDB,sys_dr,nodn,nodn,NULL,1};
 apps[6]=(App){"Settings",0xC4C7D1,0x8A8E9B,set_dr,set_dn,set_mv,set_up,0};apps[7]=(App){"Browser",0x5AD2F4,0x2A7BDE,br_dr,br_dn,br_mv,br_up,0};apps[8]=(App){"Terminal",0x7B8394,0x3C4252,term_dr,nodn,nodn,term_up,1};apps[9]=(App){"Linux Apps",0x34D399,0x0F9D7A,lapps_dr,lapps_dn,lapps_mv,lapps_up,0};}
static unsigned char*sqc[8];static int sqn[8],sqk;
static unsigned char*sqmask(int ds){for(int i=0;i<8;i++)if(sqn[i]==ds&&sqc[i])return sqc[i];int k=sqk++&7;free(sqc[k]);sqc[k]=malloc((size_t)ds*ds);sqn[k]=ds;
 for(int j=0;j<ds;j++)for(int i=0;i<ds;i++){float nx=(i+.5f)/ds*2-1,ny=(j+.5f)/ds*2-1,v=powf(fabsf(nx),5.f)+powf(fabsf(ny),5.f),d=(powf(v,.2f)-1)*ds*.5f;sqc[k][j*ds+i]=(unsigned char)(CL(.5f-d,0,1)*255);}return sqc[k];}
static void squircle(float cx,float cy,float s,u32 c1,u32 c2,float a){int ds=(int)(s*X.s*SC+.5f);if(ds<6)return;unsigned char*m=sqmask(ds);int x0=(int)floorf(tx(cx)-ds*.5f+.5f),y0=(int)floorf(ty(cy)-ds*.5f+.5f);
 u32 sh=mix(c2,0,.5f);for(int L=0;L<3;L++){int yo=(int)((2+L*1.6f)*X.s*SC);float al=.085f*a;for(int j=0;j<ds;j++)for(int i=0;i<ds;i++){int mv=m[j*ds+i];if(mv)bl(x0+i,y0+j+yo,sh,al*mv/255.f);}}
 for(int j=0;j<ds;j++)for(int i=0;i<ds;i++){int mv=m[j*ds+i];if(!mv)continue;float t=((float)i/ds+(float)j/ds)*.5f;u32 col=mix(c1,c2,t);float gl=.22f*CL(1-(float)j/ds*2.1f,0,1);if(gl>0)col=mix(col,0xFFFFFF,gl);bl(x0+i,y0+j,col,a*mv/255.f);}}
static void label(float cx,float y,const char*nm){char b[48];snprintf(b,48,"%s",nm);while(tw(b,11,1)>80&&strlen(b)>4){b[strlen(b)-1]=0;}if(strlen(b)<strlen(nm)){size_t n=strlen(b);b[n-1]='.';b[n]='.';b[n+1]=0;}T(cx,y,11,b,INK(),1,1,1);}
static void icon(int id,float cx,float cy,float s){
 if(id>=10){static const u32 LC[10][2]={{0x6EC6FF,0x2D7DD2},{0x8BE28B,0x2E9E4F},{0xFFB86B,0xE86A33},{0xB197FC,0x6741D9},{0xFF8FA3,0xD6336C},{0x63E6BE,0x0CA678},{0xFFD43B,0xF08C00},{0x74C0FC,0x1C7ED6},{0xDA77F2,0x9C36B5},{0xA9E34B,0x5C940D}};
  squircle(cx,cy,s,LC[id%10][0],LC[id%10][1],1);
  char l[2]={(char)toupper((unsigned char)(id>=20?da[id-20].name[0]:PK[id-10].n[0])),0};T(cx,cy-s*.3f,s*.55f,l,0xFFFFFF,1,1,1);return;}
 App*a=&apps[id];float k=s/62;squircle(cx,cy,s,a->c1,a->c2,1);u32 w=0xFFFFFF;
 switch(id){case 0:ring(cx,cy,17*k,3.2f*k,w,1,1);line(cx,cy,cx,cy-11*k,2.6f*k,w,1);line(cx,cy,cx+8*k,cy+4*k,2.6f*k,w,1);break;
 case 1:RR(cx-16*k,cy-19*k,32*k,12*k,4*k,w,1);for(int r=0;r<3;r++)for(int c=0;c<3;c++)RR(cx-16*k+c*12*k,cy-3*k+r*10*k,8*k,7*k,3*k,w,.9f);break;
 case 2:RR(cx-14*k,cy-18*k,28*k,36*k,6*k,w,1);for(int i=0;i<3;i++)RR(cx-8*k,cy-9*k+i*9*k,16*k,3*k,1.5f*k,a->c2,.8f);break;
 case 3:{RR(cx-18*k,cy-18*k,36*k,36*k,7*k,w,1);RG(cx-18*k,cy-18*k,36*k,10*k,5*k,a->c1,a->c2,1);struct tm t=tmnow();char b[8];sprintf(b,"%d",t.tm_mday);T(cx,cy-6*k,19*k,b,0x333333,1,1,1);break;}
 case 4:line(cx-14*k,cy+10*k,cx+6*k,cy+10*k,7*k,w,1);line(cx+6*k,cy+10*k,cx+6*k,cy-1*k,7*k,w,1);line(cx+6*k,cy-1*k,cx-8*k,cy-1*k,7*k,w,1);line(cx-8*k,cy-1*k,cx-8*k,cy-11*k,7*k,w,1);RR(cx-4*k,cy-15*k,8*k,8*k,4*k,a->c2,1);break;
 case 5:for(int i=0;i<4;i++)RR(cx-15*k+i*8.5f*k,cy+12*k-(6+i*5)*k,6*k,(6+i*5)*k,2*k,w,1);break;
 case 8:chev(cx-7*k,cy-1*k,8*k,2,w,1);line(cx+2*k,cy+9*k,cx+14*k,cy+9*k,3.2f*k,w,1);break;
 case 9:RR(cx-15*k,cy-9*k,30*k,24*k,4*k,w,1);RR(cx-17*k,cy-17*k,34*k,10*k,4*k,w,1);RR(cx-4*k,cy-17*k,8*k,10*k,0,a->c2,.55f);break;
 case 7:ring(cx,cy,16*k,2.8f*k,w,1,1);line(cx-16*k,cy,cx+16*k,cy,2.4f*k,w,1);line(cx,cy-16*k,cx,cy+16*k,2.4f*k,w,1);line(cx-12*k,cy-8*k,cx+12*k,cy-8*k,2*k,w,1);line(cx-12*k,cy+8*k,cx+12*k,cy+8*k,2*k,w,1);ring(cx,cy,7*k,2.2f*k,w,1,1);break;
 case 6:ring(cx,cy,10*k,5.5f*k,w,1,1);for(int i=0;i<8;i++){float an=i*.7853982f;line(cx+sinf(an)*13*k,cy-cosf(an)*13*k,cx+sinf(an)*17.5f*k,cy-cosf(an)*17.5f*k,5*k,w,1);}break;}}
static void openApp(int id);
enum{M_NONE,M_UNLOCK,M_CC,M_CCX,M_HOME,M_APP,M_KB,M_CCUI,M_SW,M_DRAG,M_HPAGE,M_LIB,M_LIBUI,M_CCDRAG};
static struct{int down,mode;float sx,sy,x,y,vy;double lt,t0;float ly;}P;
// ---------- home layout: movable and removable icons, pages, app library ----------
#define NSLOT 28
static int hs[NSLOT],dkk[4]={0,1,2,6},hpage,editMode,lauSeen[10],candId=-1,candSlot,dragId=-1,dragFrom=-1,nlib,libids[96];
static float hpx,hpT,hbase,dragX,dragY,edgeT,libP,libT,libsc,libsy;static char libq[40];
static const char*appname(int id);
static int appok(int id);
static const char*appname(int id){return id>=20?da[id-20].name:id>=10?PK[id-10].n:apps[id].n;}
static int appok(int id){return id<10||(id<20&&lins[id-10])||(id>=20&&id<20+ND&&da[id-20].name[0]);}
static void lay_save(void){FILE*f=fopen(SAVE"/layout.bin","wb");if(f){int m=0x4C41;fwrite(&m,4,1,f);fwrite(hs,sizeof hs,1,f);fwrite(dkk,sizeof dkk,1,f);fwrite(lauSeen,sizeof lauSeen,1,f);fclose(f);}}
static void lay_load(void){static const int gr[6]={3,4,5,7,8,9};for(int i=0;i<NSLOT;i++)hs[i]=-1;for(int i=0;i<6;i++)hs[i]=gr[i];
 FILE*f=fopen(SAVE"/layout.bin","rb");if(f){int m=0;if(fread(&m,4,1,f)==1&&m==0x4C41){if(fread(hs,sizeof hs,1,f)!=1){}if(fread(dkk,sizeof dkk,1,f)!=1){}if(fread(lauSeen,sizeof lauSeen,1,f)!=1){}}fclose(f);}
 for(int q=8;q<12;q++)if(hs[q]>=0){int id=hs[q];hs[q]=-1;for(int t=12;t<NSLOT;t++)if(hs[t]<0){hs[t]=id;break;}}}
static int slotok(int s){return s<8||s>=12;}
static void slotxy(int s,float*x,float*y){if(s<12){*x=45+90*(s%4);*y=300+92*(s/4);}else{int t=s-12;*x=45+90*(t%4);*y=100+92*(t/4);}}
static float pgoff(int s){return s<12?-hpx*360:(1-hpx)*360;}
static void dockxy(int i,float*x,float*y){*x=54+84*i;*y=575;}
static int onhome(int id){for(int i=0;i<NSLOT;i++)if(hs[i]==id)return 1;for(int i=0;i<4;i++)if(dkk[i]==id)return 1;return 0;}
static int addhome(int id){if(onhome(id))return 1;for(int i=0;i<NSLOT;i++)if(slotok(i)&&hs[i]<0){hs[i]=id;lay_save();return 1;}return 0;}
static void rmhome(int id){for(int i=0;i<NSLOT;i++)if(hs[i]==id)hs[i]=-1;for(int i=0;i<4;i++)if(dkk[i]==id)dkk[i]=-1;}
static void lay_save(void);
// --- apps found on the system (.desktop files from apk and Flatpak, plus packages installed from the terminal)
static void da_save(void){FILE*f=fopen(SAVE"/apps.reg","wb");if(f){fwrite(da,sizeof da,1,f);fclose(f);}}
static void da_load(void){FILE*f=fopen(SAVE"/apps.reg","rb");if(f){if(fread(da,sizeof da,1,f)!=1)memset(da,0,sizeof da);fclose(f);}for(int i=0;i<ND;i++)da[i].valid=0;}
static int da_find(const char*cmd){for(int i=0;i<ND;i++)if(da[i].name[0]&&!strcmp(da[i].cmd,cmd))return i;return -1;}
static int da_isPK(const char*cmd){char w[64];int k=0;const char*p=cmd;while(*p==' ')p++;const char*b=p;for(;*p&&*p!=' ';p++)if(*p=='/')b=p+1;while(*b&&*b!=' '&&k<63)w[k++]=*b++;w[k]=0;for(int i=0;i<10;i++)if(!strcmp(w,PK[i].bin))return 1;return 0;}
static int da_put(const char*name,const char*cmd,int term,int custom){if(!name[0]||!cmd[0]||da_isPK(cmd))return -1;int i=da_find(cmd);int fresh=0;if(i<0){for(i=0;i<ND&&da[i].name[0];i++);if(i>=ND)return -1;fresh=1;memset(&da[i],0,sizeof da[i]);}
 snprintf(da[i].name,40,"%s",name);snprintf(da[i].cmd,240,"%s",cmd);da[i].term=term;da[i].custom=custom;da[i].valid=1;if(fresh||!da[i].seen){da[i].seen=1;addhome(20+i);da_save();}return i;}
static void desk_parse(const char*path){FILE*f=fopen(path,"r");if(!f)return;char l[600],name[60]="",ex[400]="";int term=0,hide=0,app=1,ingrp=0;
 while(fgets(l,600,f)){l[strcspn(l,"\r\n")]=0;if(l[0]=='['){ingrp=!strcmp(l,"[Desktop Entry]");if(!ingrp&&name[0])break;continue;}if(!ingrp)continue;
  if(!strncmp(l,"Name=",5))snprintf(name,60,"%s",l+5);else if(!strncmp(l,"Exec=",5))snprintf(ex,400,"%s",l+5);else if(!strcmp(l,"Terminal=true"))term=1;
  else if(!strcmp(l,"NoDisplay=true")||!strcmp(l,"Hidden=true"))hide=1;else if(!strncmp(l,"Type=",5)&&strcmp(l+5,"Application"))app=0;}
 fclose(f);if(hide||!app||!name[0]||!ex[0])return;
 char cmd[240]="";int k=0;for(char*t=strtok(ex," ");t;t=strtok(NULL," ")){if(t[0]=='%'||!strncmp(t,"@@",2))continue;k+=snprintf(cmd+k,240-k,"%s%s",k?" ":"",t);if(k>=230)break;}
 da_put(name,cmd,term,0);}
static void desk_scan(void){static double t=-9;if(NOW-t<5)return;t=NOW;for(int i=0;i<ND;i++)da[i].valid=0;
 const char*env=getenv("FADAN_APPDIRS");const char*dirs[]={"/usr/share/applications","/usr/local/share/applications","/var/lib/flatpak/exports/share/applications","/root/.local/share/flatpak/exports/share/applications","/root/.local/share/applications"};
 int nd_=env?1:5;for(int d=0;d<nd_;d++){const char*dp=env?env:dirs[d];DIR*D=opendir(dp);struct dirent*e;if(!D)continue;while((e=readdir(D))){size_t n=strlen(e->d_name);if(n>8&&!strcmp(e->d_name+n-8,".desktop")){char p[400];snprintf(p,400,"%s/%s",dp,e->d_name);desk_parse(p);}}closedir(D);}
 FILE*f=fopen(SAVE"/custom-pkgs.txt","r");if(f){char l[80];while(fgets(l,80,f)){l[strcspn(l,"\r\n")]=0;if(!l[0]||strchr(l,'/')||strchr(l,' '))continue;char p[120];snprintf(p,120,"/usr/bin/%s",l);if(access(p,X_OK)==0){char cmd[100];snprintf(cmd,100,"%s",l);if(da_find(cmd)<0||1)da_put(l,cmd,1,1);}}fclose(f);}
 int ch=0;for(int i=0;i<ND;i++)if(da[i].name[0]&&!da[i].valid){rmhome(20+i);memset(&da[i],0,sizeof da[i]);ch=1;}if(ch){da_save();lay_save();}}
static void lau_sync(void){desk_scan();static double t=-9;if(NOW-t<3)return;t=NOW;int ch=0;for(int i=0;i<10;i++){int id=10+i,inst=pkinst(PK[i].bin);lins[i]=inst;
 if(inst&&!lauSeen[i]){lauSeen[i]=1;if(!onhome(id))addhome(id);ch=1;}else if(!inst&&lauSeen[i]){lauSeen[i]=0;rmhome(id);ch=1;}}if(ch)lay_save();}
static void apos(int id,float*x,float*y){for(int i=0;i<4;i++)if(dkk[i]==id){dockxy(i,x,y);return;}for(int s=0;s<NSLOT;s++)if(hs[s]==id){slotxy(s,x,y);*x+=pgoff(s);return;}*x=180;*y=500;}
static int homeAt(float x,float y,int*slot,float*cx,float*cy){if(hpx>.02f&&hpx<.98f)return -1;
 for(int i=0;i<4;i++)if(dkk[i]>=0){float ax,ay;dockxy(i,&ax,&ay);if(in(x,y,ax-34,ay-34,68,68)){*slot=100+i;*cx=ax;*cy=ay;return dkk[i];}}
 for(int s=0;s<NSLOT;s++)if(slotok(s)&&hs[s]>=0){float ax,ay;slotxy(s,&ax,&ay);ax+=pgoff(s);if(in(x,y,ax-34,ay-34,68,76)){*slot=s;*cx=ax;*cy=ay;return hs[s];}}return -1;}
static void activate(int id){if(id>=20){DA*d=&da[id-20];if(d->term){launchTerm(d->cmd);}else if(access("/usr/bin/cage",X_OK)!=0){launchTerm("fadan-gui-setup");}else{FILE*f=fopen("/run/fadan-gui.cmd","w");if(f){fputs(d->cmd,f);fclose(f);}}return;}
 if(id>=10){launchTerm(PK[id-10].bin);return;}openApp(id);}
static void startDrag(void){dragId=candId;dragFrom=candSlot;if(dragFrom>=100)dkk[dragFrom-100]=-1;else hs[dragFrom]=-1;dragX=P.x;dragY=P.y;}
static void dropIcon(float x,float y){int id=dragId;if(id<0)return;dragId=-1;int tgt=-1;
 if(y>520){float best=1e9f;for(int i=0;i<4;i++){float d=fabsf(x-(54+84*i));if(d<best){best=d;tgt=100+i;}}}
 else{float best=64;for(int s=0;s<NSLOT;s++){if(!slotok(s))continue;float sx,sy;slotxy(s,&sx,&sy);sx+=pgoff(s);float d=hypotf(x-sx,y-sy);if(d<best){best=d;tgt=s;}}}
 if(tgt<0)tgt=dragFrom;int*tp=tgt>=100?&dkk[tgt-100]:&hs[tgt];int other=*tp;*tp=id;
 if(other>=0){int*fp=dragFrom>=100?&dkk[dragFrom-100]:&hs[dragFrom];if(*fp<0)*fp=other;else addhome(other);}lay_save();}
static void lib_key(int ch){size_t n=strlen(libq);if(ch==8){if(n)libq[n-1]=0;}else if(ch==10){libEdit=0;kbWant=0;}else if(ch>=32&&ch<127&&n<30){libq[n]=ch;libq[n+1]=0;}libsc=0;}
static void lib_build(void){nlib=0;for(int id=0;id<20+ND;id++){if(!appok(id))continue;if(libq[0]&&!strcasestr(appname(id),libq))continue;libids[nlib++]=id;}
 for(int i=1;i<nlib;i++){int v=libids[i],j=i-1;while(j>=0&&strcasecmp(appname(libids[j]),appname(v))>0){libids[j+1]=libids[j];j--;}libids[j+1]=v;}}
static float libmax(void){float m=190+100*((nlib+3)/4)-560;return m>0?m:0;}
static void draw_lib(void){if(libP<.003f)return;idX();lib_build();blur_area(0,0,W,H,libP);RR(0,0,360,640,0,0,.12f*libP);X.oy=(1-libP)*640;X.a=libP;RR(0,0,360,640,30,BG(),.74f);
 for(int i=0;i<nlib;i++){float x=45+90*(i%4),y=200+100*(i/4)-libsc;if(y<150||y>650)continue;icon(libids[i],x,y,62);label(x,y+37,appname(libids[i]));
  if(!onhome(libids[i])){RR(x+16,y-38,22,22,11,0x34C759,1);line(x+21,y-27,x+33,y-27,2.4f,0xFFFFFF,1);line(x+27,y-33,x+27,y-21,2.4f,0xFFFFFF,1);}}
 if(!nlib)T(180,300,15,"No apps found",MUT(),1,1,0);
 RR(0,0,360,142,0,BG(),.55f);T(20,40,30,"Apps",INK(),1,0,1);RR(16,92,328,40,20,CARD(),1);char b[64];snprintf(b,64,"%s%s",libq,libEdit&&fmod(NOW,1.)<.6?"|":"");
 T(34,102,15,libq[0]||libEdit?b:"Search apps",libq[0]||libEdit?INK():MUT(),1,0,0);idX();}
static void lib_tap(float x,float y){if(y>618){libT=0;libOn=0;libEdit=0;kbWant=0;return;}
 if(in(x,y,16,92,328,40)){libEdit=1;kbWant=1;return;}libEdit=0;kbWant=0;
 for(int i=0;i<nlib;i++){float cx=45+90*(i%4),cy=200+100*(i/4)-libsc;if(cy<150)continue;int id=libids[i];
  if(!onhome(id)&&in(x,y,cx+8,cy-44,36,36)){addhome(id);return;}
  if(in(x,y,cx-34,cy-34,68,76)){libT=0;libOn=0;activate(id);return;}}}
// ---------- system state ----------
static int rec[10],nrec,swOn,swaxis,swcard;static float swP,swPos,swPosT,swbase,dismY[10];
static int locked=1,booting=1,ccslide;static float unlockP,unlockT,ccP,ccT,openP,iox,ioy,bootT;
static float cch=270;
#define CCH cch
static void recpush(int id){int i;for(i=0;i<nrec&&rec[i]!=id;i++);if(i==nrec){if(nrec<10)nrec++;i=nrec-1;}memmove(rec+1,rec,i*sizeof(int));rec[0]=id;}
static void bstop(void);
static void quitApp(int id){if(id==7)bstop();if(id==6){setpage=0;kbWant=0;}if(id==4)sl=0;if(id==2){ned=-1;kbWant=0;}if(id==0)ctab=0;}
static void dismiss(int k){quitApp(rec[k]);memmove(rec+k,rec+k+1,(nrec-k-1)*sizeof(int));memmove(dismY+k,dismY+k+1,(nrec-k-1)*sizeof(float));nrec--;dismY[nrec]=0;if(!nrec)swOn=0;swPosT=CL(roundf(swPosT),0,fmaxf(nrec-1,0));}
static void lock(void){swOn=0;editMode=0;libT=0;libOn=0;locked=1;unlockT=0;if(cur>=0){openP=openT=0;cur=-1;}ccT=0;kbWant=0;}
static void openApp(int id){editMode=0;if(!swOn)recpush(id);cur=id;os0=tos0=.17f;orad=torad=95;oa0=0;swHide=-1;apos(id,&iox,&ioy);tiox=iox;tioy=ioy;openP=0;openT=1;kbWant=0;if(id==4&&!sl)sreset();if(id==8){tstart();kbWant=1;}if(id==2)ned=-1;}
static void closeApp(void){openT=0;kbWant=0;if(cur>=0){apos(cur,&tiox,&tioy);tos0=.17f;torad=95;oa0=0;}}
static int batcap=-1,batchg;static double batt_t=-9;static char blp[200];static int blmax,lastbr=-1;
static void batt_read(void){if(NOW-batt_t<5)return;batt_t=NOW;batcap=-1;DIR*d=opendir("/sys/class/power_supply");struct dirent*e;if(!d)return;
 while((e=readdir(d))){char p[300],v[40];snprintf(p,300,"/sys/class/power_supply/%s/type",e->d_name);FILE*f=fopen(p,"r");if(!f)continue;if(!fgets(v,40,f)){fclose(f);continue;}fclose(f);if(strncmp(v,"Battery",7))continue;
  snprintf(p,300,"/sys/class/power_supply/%s/capacity",e->d_name);f=fopen(p,"r");if(f){if(fscanf(f,"%d",&batcap)!=1)batcap=-1;fclose(f);}
  snprintf(p,300,"/sys/class/power_supply/%s/status",e->d_name);f=fopen(p,"r");batchg=0;if(f){if(fgets(v,40,f))batchg=!strncmp(v,"Charging",8)||!strncmp(v,"Full",4);fclose(f);}break;}closedir(d);}
static void bl_find(void){DIR*d=opendir("/sys/class/backlight");struct dirent*e;blp[0]=0;if(!d)return;while((e=readdir(d)))if(e->d_name[0]!='.'){char p[300];snprintf(p,300,"/sys/class/backlight/%s/max_brightness",e->d_name);FILE*f=fopen(p,"r");if(f){if(fscanf(f,"%d",&blmax)==1&&blmax>0)snprintf(blp,200,"/sys/class/backlight/%s/brightness",e->d_name);fclose(f);if(blp[0])break;}}closedir(d);}
static void bl_apply(void){if(!blp[0])return;FILE*f=fopen(blp,"w");if(f){int v=blmax*S.br/100;if(v<1)v=1;fprintf(f,"%d",v);fclose(f);}}
static void statusbar(void){char b[16];struct tm t=tmnow();fmt_time(b,16,&t);T(22,7,14,b,INK(),1,0,1);batt_read();float rx=348;
 if(batcap>=0){int cap=batcap;RR(310,9,26,13,4,INK(),.35f);RR(312,11,fmaxf(2,21*cap/100.f),9,3,(cap<=15&&!batchg)?0xE0453A:(batchg?0x34C759:INK()),1);RR(337,13,2,5,1,INK(),.35f);char pc[8];snprintf(pc,8,"%d%%",cap);T(305,8,11,pc,INK(),.8f,2,1);rx=300-tw(pc,11,1)-8;}
 int mob=mm_state[0]&&mm_sig>=0&&S.mobile&&(strstr(mm_state,"registered")||strstr(mm_state,"connected")),wf=wlok&&st_ssid[0]&&!S.airplane;
 if(mob){int l=mm_sig>75?4:mm_sig>50?3:mm_sig>25?2:1;for(int i=0;i<4;i++)RR(rx-20+i*5,17-i*3,3,4+i*3,1,INK(),i<l?1:.25f);rx-=28;}
 if(wf){int l=st_sig>-55?3:st_sig>-70?2:1;float cx=rx-9,cy=14,f=l/3.f;tri(cx-8,cy-4,cx+8,cy-4,cx,cy+5,INK(),.25f);tri(cx-8*f,cy+5-9*f,cx+8*f,cy+5-9*f,cx,cy+5,INK(),1);rx-=26;}
 else if(st_ip[0]&&!mob&&!S.airplane){ring(rx-8,14,5,1.8f,INK(),1,1);line(rx-13,14,rx-3,14,1.4f,INK(),1);rx-=24;}}
static void hicon(int id,float cx,float cy,int lab,int slot){float jx=0,jy=0;if(editMode&&id!=dragId){jx=sinf((float)NOW*17+slot*1.9f)*1.1f;jy=cosf((float)NOW*15+slot*2.3f)*1.1f;}
 icon(id,cx+jx,cy+jy,(P.down&&P.mode==M_NONE&&candId==id&&!editMode)?57:62);if(lab)label(cx+jx,cy+jy+37,appname(id));
 if(editMode){RR(cx+jx-38,cy+jy-38,22,22,11,0x8E8E93,1);line(cx+jx-33,cy+jy-27,cx+jx-21,cy+jy-27,2.6f,0xFFFFFF,1);}}
static void draw_widgets(float o0){struct tm t=tmnow();char b[64];int hr=t.tm_hour;const char*gr=hr<5?"Good night":hr<12?"Good morning":hr<18?"Good afternoon":"Good evening";
 RR(17+o0,45,326,106,31,0xFFFFFF,S.dark?.1f:.28f);GL(18+o0,46,324,104,30,mix(GT(),ACC(),.09f),GA()+.08f,1);fmt_time(b,16,&t);T(36+o0,54,50,b,INK(),1,0,0);strftime(b,64,"%A, %d %B",&t);T(38+o0,112,15,b,MUT(),1,0,0);T(326+o0,60,14,gr,MUT(),1,2,1);
 GL(18+o0,160,156,76,26,GT(),GA(),1);strftime(b,32,"%d",&t);T(36+o0,170,38,b,ACC(),1,0,1);strftime(b,64,"%B",&t);T(92+o0,174,15,b,INK(),1,0,1);strftime(b,64,"%A",&t);T(92+o0,196,12,b,MUT(),1,0,0);
 GL(186+o0,160,156,76,26,GT(),GA(),1);float v;const char*lb,*sb;char pc[16];
 if(batcap>=0){v=batcap/100.f;lb="Battery";sb=batchg?"Charging":"On battery";}else{struct sysinfo si;sysinfo(&si);v=si.totalram?1-(float)si.freeram/si.totalram:0;lb="Memory";sb="RAM in use";}
 ring(224+o0,198,20,5,INK(),.14f,1);ring(224+o0,198,20,5,ACC(),1,fmaxf(.03f,v));snprintf(pc,16,"%d%%",(int)(v*100+.5f));T(224+o0,191,12,pc,INK(),1,1,1);T(256+o0,174,15,lb,INK(),1,0,1);T(256+o0,196,12,sb,MUT(),1,0,0);}
static void draw_home(void){float o0=-hpx*360;
 if(hpx<.99f){float sa=X.a;if(editMode)X.a*=.3f;draw_widgets(o0);X.a=sa;}
 for(int s=0;s<NSLOT;s++){int id=hs[s];if(id<0||!slotok(s))continue;float x,y;slotxy(s,&x,&y);x+=pgoff(s);if(fabsf(x-180)>260)continue;hicon(id,x,y,1,s);}
 for(int p=0;p<2;p++){float dx=180+(p-.5f)*18;if(p==hpage)RR(dx-8,476,16,6,3,ACC(),1);else RR(dx-3,476,6,6,3,INK(),.25f);}
 if(editMode){pill(135,494,90,28,ACC(),1);T(180,500,14,"Done",0xFFFFFF,1,1,1);}else{RR(124,493,112,30,15,0xFFFFFF,S.dark?.08f:.25f);GL(125,494,110,28,14,GT(),GA()+.1f,1);T(180,500,13,"Search",MUT(),1,1,0);}
 RR(13,533,334,86,31,0xFFFFFF,S.dark?.1f:.34f);GL(14,534,332,84,30,GT(),GA()+.06f,1);RR(34,535.5f,292,1.4f,.7f,0xFFFFFF,S.dark?.16f:.7f);for(int i=0;i<4;i++)if(dkk[i]>=0){float x,y;dockxy(i,&x,&y);hicon(dkk[i],x,y,0,100+i);}
 if(dragId>=0){RR(dragX-31,dragY-27,62,62,17,0,.22f);icon(dragId,dragX,dragY-4,70);}}
static void chip(float cx,float y,const char*t){float w=tw(t,13,1)+28;RR(cx-w/2-1,y-1,w+2,30,15,0xFFFFFF,S.dark?.1f:.3f);GL(cx-w/2,y,w,28,14,GT(),GA()+.1f,1);T(cx,y+6,13,t,INK(),1,1,1);}
static void draw_lock(void){float off=unlockP*660;X.oy=-off;X.a=1-unlockP*.7f;struct tm t=tmnow();char b[64],d2[64];fmt_time(b,16,&t);strftime(d2,64,"%A, %d %B",&t);
 T(180,62,19,d2,INK(),.8f,1,1);T(180,90,108,b,INK(),1,1,0);RR(158,214,44,4,2,ACC(),1);
 char c1[48];if(st_ssid[0])snprintf(c1,48,"%.30s",st_ssid);else snprintf(c1,48,"%s",st_ip[0]?"Online":"Offline");batt_read();
 if(batcap>=0){char c2[24];snprintf(c2,24,"%d%%%s",batcap,batchg?" charging":"");float w1=tw(c1,13,1)+28,w2=tw(c2,13,1)+28,tot=w1+w2+10;chip(180-tot/2+w1/2,496,c1);chip(180+tot/2-w2/2,496,c2);}else chip(180,496,c1);
 float bn=sinf((float)NOW*3)*3;chev(180,566+bn,9,0,MUT(),1);T(180,590,13,"Swipe up to unlock",MUT(),1,1,0);idX();}
// ---------- editable control center ----------
typedef struct{const char*name;int kind,app;}CT;
static const CT CTS[16]={{"Fadan UI",0,0},{"Dark",0,0},{"Night",0,0},{"24-hour",0,0},{"Wi-Fi",0,0},{"Mobile",0,0},{"Lock",1,0},{"Settings",2,6},{"Terminal",2,8},{"Calculator",2,1},{"Clock",2,0},{"Notes",2,2},{"Browser",2,7},{"Calendar",2,3},{"All apps",1,0},{"Brightness",3,0}};
static int ccl[16]={0,1,2,3,15,4,6,7},ccn=8,ccEdit,ccPick,ccDrag=-1,ccCand=-1;static float ccDX,ccDY;
typedef struct{float x,y,w,h;}Rc;
static void cc_save(void){FILE*f=fopen(SAVE"/cc.bin","wb");if(f){int m=0x4343;fwrite(&m,4,1,f);fwrite(&ccn,4,1,f);fwrite(ccl,sizeof ccl,1,f);fclose(f);}}
static void cc_load(void){FILE*f=fopen(SAVE"/cc.bin","rb");if(f){int m=0,n=0,t[16];if(fread(&m,4,1,f)==1&&m==0x4343&&fread(&n,4,1,f)==1&&n>=0&&n<=16&&fread(t,sizeof t,1,f)==1){ccn=n;memcpy(ccl,t,sizeof t);}fclose(f);}}
static int ccin(int id){for(int i=0;i<ccn;i++)if(ccl[i]==id)return 1;return 0;}
static void cc_layout(Rc*r){float y=48;int col=0;for(int i=0;i<ccn;i++){if(ccl[i]==15){if(col){y+=84;col=0;}r[i]=(Rc){18,y,324,56};y+=64;}else{r[i]=(Rc){18+col*82.f,y,72,76};if(++col==4){col=0;y+=84;}}}
 if(ccEdit&&ccn<16){r[ccn]=(Rc){18+col*82.f,y,72,76};if(++col==4){col=0;y+=84;}}if(col)y+=84;cch=y+(ccEdit?50:14);}
static int ctstate(int id){switch(id){case 0:return S.fadan;case 1:return S.dark;case 2:return S.night;case 3:return S.h24;case 4:return !S.airplane;case 5:return S.mobile;}return 0;}
static int ctdis(int id){return (id==4&&!wlok)||(id==5&&!mm_state[0]);}
static void ctact(int id){const CT*t=&CTS[id];
 if(t->kind==0){if(ctdis(id))return;switch(id){case 0:S.fadan^=1;setchg();break;case 1:S.dark^=1;setchg();break;case 2:S.night^=1;setchg();break;case 3:S.h24^=1;setchg();break;
  case 4:S.airplane^=1;net_set(!S.airplane);nett=-9;sset();break;
  case 5:S.mobile^=1;
#ifndef TEST
   (void)!system(S.mobile?"/usr/local/bin/fadan-mobile on >/dev/null 2>&1 &":"/usr/local/bin/fadan-mobile off >/dev/null 2>&1 &");
#endif
   nett=-9;sset();break;}}
 else if(id==6){lock();}else if(id==14){ccT=0;libT=1;libOn=1;libEdit=0;libsc=0;}
 else if(t->kind==2){ccT=0;if(cur>=0){closeApp();launch=t->app;}else activate(t->app);}}
static void cc_icon(int id,float cx,float cy,u32 c,u32 bgc){switch(id){
 case 0:ring(cx,cy,10,3,c,1,1);RR(cx-5,cy-5,10,10,5,c,1);break;case 1:ring(cx,cy,10,3,c,1,1);RR(cx-5,cy-10,5,20,2.5f,c,1);break;
 case 2:RR(cx-11,cy-11,22,22,11,c,1);RR(cx-5,cy-14,20,20,10,bgc,1);break;case 3:T(cx,cy-10,21,"24",c,1,1,1);break;
 case 4:tri(cx-11,cy-6,cx+11,cy-6,cx,cy+9,c,1);break;case 5:for(int i=0;i<4;i++)RR(cx-10+i*6,cy+8-(4+i*4),4,4+i*4,1.5f,c,1);break;
 case 6:RR(cx-8,cy-2,16,13,3,c,1);ring(cx,cy-3,5,2.2f,c,1,1);break;case 14:for(int a=0;a<2;a++)for(int b=0;b<2;b++)RR(cx-10+a*12,cy-10+b*12,8,8,2.5f,c,1);break;}}
static void cc_tile(int id,Rc r,float jx,float jy){const CT*t=&CTS[id];int on=t->kind==0&&ctstate(id)&&!ctdis(id);u32 bgc=on?ACC():CARD();float al=ctdis(id)?.5f:1,x=r.x+jx,y=r.y+jy,sa=X.a;
 RR(x,y,r.w,r.h,22,bgc,(on?1:.82f)*al);u32 c=on?0xFFFFFF:INK();float cx=x+r.w/2,cy=y+28;X.a*=al;if(t->kind==2)icon(t->app,cx,cy-2,38);else cc_icon(id,cx,cy,c,bgc);T(cx,y+55,11,t->name,c,1,1,0);X.a=sa;}
static void cc_wide(Rc r,float jx,float jy){float x=r.x+jx,y=r.y+jy;card(x,y,r.w,r.h);RR(x+16,y+10,10,10,5,MUT(),1);T(x+34,y+8,12,"Brightness",MUT(),1,0,0);slider(x+30,y+38,280,(S.br-30)/70.f);}
static void cc_pick_geo(int*av,int*na){*na=0;for(int id=0;id<16;id++)if(!ccin(id))av[(*na)++]=id;}
static void draw_cc(void){if(ccP<.002f)return;Rc r[18];cc_layout(r);idX();blur_area(0,0,W,H,ccP);RR(0,0,360,640,0,0,.1f*ccP);X.oy=-(1-ccP)*(CCH+20);
 RR(-11,-61,382,CCH+62,37,0xFFFFFF,S.dark?.1f:.3f);RR(-10,-60,380,CCH+60,36,GT(),S.dark?.55f:.5f);
 for(int i=0;i<ccn;i++){if(i==ccDrag)continue;float jx=0,jy=0;if(ccEdit){jx=sinf((float)NOW*17+i*1.9f)*1.1f;jy=cosf((float)NOW*15+i*2.3f)*1.1f;}
  if(ccl[i]==15)cc_wide(r[i],jx,jy);else cc_tile(ccl[i],r[i],jx,jy);
  if(ccEdit){RR(r[i].x+jx-6,r[i].y+jy-6,22,22,11,0x8E8E93,1);line(r[i].x+jx-1,r[i].y+jy+5,r[i].x+jx+9,r[i].y+jy+5,2.4f,0xFFFFFF,1);}}
 if(ccEdit&&ccn<16){Rc a=r[ccn];RR(a.x,a.y,a.w,a.h,22,CARD(),.5f);line(a.x+36,a.y+26,a.x+36,a.y+50,3,MUT(),1);line(a.x+24,a.y+38,a.x+48,a.y+38,3,MUT(),1);}
 if(ccDrag>=0&&ccDrag<ccn){Rc d=r[ccDrag],q={ccDX-d.w/2,ccDY-d.h/2,d.w,d.h};RR(q.x+2,q.y+6,q.w,q.h,22,0,.2f);if(ccl[ccDrag]==15)cc_wide(q,0,0);else cc_tile(ccl[ccDrag],q,0,0);}
 if(ccEdit){pill(130,CCH-46,100,32,ACC(),1);T(180,CCH-40,14,"Done",0xFFFFFF,1,1,1);}else RR(155,CCH-12,50,5,2.5f,MUT(),.5f);
 if(ccPick){int av[16],na;cc_pick_geo(av,&na);idX();RR(0,0,360,640,0,0,.35f);float rows=na?(na+1)/2:1;float h=64+rows*44;RR(15,89,330,h+2,29,0xFFFFFF,S.dark?.1f:.3f);RR(16,90,328,h,28,GT(),S.dark?.8f:.78f);T(180,102,16,"Add to Control Center",INK(),1,1,1);
  if(!na)T(180,150,14,"Everything is already added",MUT(),1,1,0);
  for(int k=0;k<na;k++){float x=24+(k%2)*156,y=134+(k/2)*44;RR(x,y,148,38,14,CARD(),.9f);const CT*t=&CTS[av[k]];if(t->kind==2)icon(t->app,x+22,y+19,26);T(x+(t->kind==2?44:14),y+10,13,t->name,INK(),1,0,0);}
  X.oy=0;}
 idX();}
static void cc_tap(float x,float y){Rc r[18];cc_layout(r);
 if(ccEdit){if(in(x,y,130,CCH-46,100,32)){ccEdit=0;cc_save();return;}
  for(int i=0;i<ccn;i++)if(in(x,y,r[i].x-8,r[i].y-8,26,26)){for(int k=i;k<ccn-1;k++)ccl[k]=ccl[k+1];ccn--;cc_save();return;}
  if(ccn<16&&in(x,y,r[ccn].x,r[ccn].y,72,76))ccPick=1;return;}
 for(int i=0;i<ccn;i++)if(ccl[i]!=15&&in(x,y,r[i].x,r[i].y,r[i].w,r[i].h)){ctact(ccl[i]);return;}}
static void pick_tap(float x,float y){int av[16],na;cc_pick_geo(av,&na);for(int k=0;k<na;k++){float xx=24+(k%2)*156,yy=134+(k/2)*44;if(in(x,y,xx,yy,148,38)&&ccn<16){ccl[ccn++]=av[k];cc_save();ccPick=0;return;}}ccPick=0;}
static void cc_drop(float x,float y){Rc r[18];cc_layout(r);int from=ccDrag;ccDrag=-1;if(from<0)return;int t=-1;float best=90;
 for(int i=0;i<ccn;i++){if(i==from)continue;float d=hypotf(x-(r[i].x+r[i].w/2),y-(r[i].y+r[i].h/2));if(d<best){best=d;t=i;}}
 if(t>=0){int tmp=ccl[from];ccl[from]=ccl[t];ccl[t]=tmp;cc_save();}}
static void draw_boot(void){float t=bootT,fade=t>3?1-(t-3)/.45f:1;if(fade<=0)return;idX();
 RG(0,0,360,640,0,0xF8F5F3,0xE6E2E8,fade);float sw_=CL(t/1.1f,0,1);sw_=1-powf(1-sw_,3);float ex=t>2.5f?t-2.5f:0;
 setX(1+ex*ex*9+(t<2.5f?sinf(t*3)*.03f:0),180,320,fade*(1-CL(ex/.5f,0,1)));ring(180,320,37.3f,4,ACC(),1,sw_);idX();
 const char*s="fadan";float a=CL((t-.7f)/.6f,0,1)*fade*(1-CL(ex/.4f,0,1));float tot=0;for(int i=0;i<5;i++){char c[2]={s[i],0};tot+=tw(c,30,1)+9;}float x=180-(tot-9)/2;
 for(int i=0;i<5;i++){char c[2]={s[i],0};float w=tw(c,30,1);T(x,364+(1-a)*10,30,c,0x1D1D20,a,0,1);x+=w+9;}}
static void draw_sw(void){if(swP<.003f)return;idX();blur_area(0,0,W,H,swP);RR(0,0,360,640,0,0,.3f*swP);
 if(!nrec)T(180,300,17,"No recent apps",0xFFFFFF,swP,1,0);
 for(int k=0;k<nrec;k++){float cx=180+(k-swPos)*210;if(fabsf(cx-180)>300||rec[k]==swHide)continue;float top=120+dismY[k]+(1-swP)*40,al=swP*CL(1+dismY[k]/260,.2f,1);
  X.s=.56f;X.ox=cx-100.8f;X.oy=top;X.a=al;RR(0,0,360,640,40,BG(),1);apps[rec[k]].dr();idX();T(cx,top+366,15,apps[rec[k]].n,0xFFFFFF,al,1,1);}
 if(nrec){RR(120,552,120,38,19,ACC(),swP);T(180,560,14,"Close all",0xFFFFFF,swP,1,1);}}
static void render(void){memcpy(buf,wpb,(size_t)W*H*4);idX();
 if(!booting||bootT>2.4f){
 if(unlockP>.001f){float e=cur>=0?openP:0;setX((1.08f-.08f*unlockP)*(1-.1f*e),180,320,unlockP*(1-e));draw_home();idX();}
 if(cur>=0&&openP>.001f){float e=openP,eo=e;if(openT>.5f&&!(P.down&&P.mode==M_HOME)){float q=e-1;eo=1+2.1f*q*q*q+1.1f*q*q;}float s=lerp(os0,1,eo),cx=lerp(iox,180,eo),cy=lerp(ioy,320,eo);X.s=s;X.ox=cx-180*s;X.oy=cy-320*s;X.a=lerp(oa0,1,CL(e*4,0,1));
  GL(0,0,360,640,lerp(orad,0,CL(eo,0,1)),BG(),S.dark?.9f:.88f,1);apps[cur].dr();idX();}
 draw_lib();kb_draw();draw_sw();draw_cc();statusbar();if(unlockP<.999f)draw_lock();
 RR(125,630,110,4,2,INK(),locked?0:.4f);}
 if(booting)draw_boot();
 if(S.night)RR(0,0,360,640,0,0xFF8A1E,.13f);
 if(S.br<100&&!blp[0]){RR(0,0,360,640,0,0,(100-S.br)*.007f);}}
// ---------- input handling ----------
static void p_down(float x,float y){lastIn=NOW;P.down=1;P.mode=M_NONE;P.sx=P.x=x;P.sy=P.y=y;P.vy=0;P.lt=NOW;P.ly=y;ccslide=0;if(booting)return;
 if(swOn){P.mode=M_SW;swaxis=0;swbase=swPos;swcard=-1;for(int k=0;k<nrec;k++){float cx=180+(k-swPos)*210;if(in(x,y,cx-101,120+dismY[k],202,358))swcard=k;}return;}
 P.t0=NOW;candId=-1;if(libOn&&libP>.5f&&!(kbP>.5f&&y>430&&y<620)){P.mode=M_LIBUI;libsy=y;return;}
 if(!locked&&cur<0&&!swOn&&!libOn&&ccP<.1f){float cx,cy;candId=homeAt(x,y,&candSlot,&cx,&cy);}
 if(!locked&&kbP>.5f&&y>430&&y<620){int k=kbwalk(x,y,0);if(k)kbpress(k);P.mode=M_KB;return;}
 if(ccPick)return;
 if(ccP>.5f&&y<CCH){ccCand=-1;Rc cr[18];cc_layout(cr);for(int i=0;i<ccn;i++)if(in(x,y,cr[i].x,cr[i].y,cr[i].w,cr[i].h))ccCand=i;
  if(!ccEdit&&ccCand>=0&&ccl[ccCand]==15&&in(x,y,30,cr[ccCand].y+18,300,34)){ccslide=1;S.br=30+CL((x-48)/280.f,0,1)*70;P.mode=M_CCUI;}return;}
 if(!locked&&cur>=0&&openP>.9f)apps[cur].dn(x,y);}
static void p_move(float x,float y){lastIn=NOW;float dx=x-P.sx,dy=y-P.sy;P.x=x;P.y=y;double dt=NOW-P.lt;if(dt>.001){P.vy=P.vy*.6f+(y-P.ly)/dt*.4f;P.lt=NOW;P.ly=y;}if(booting||!P.down)return;
 if(P.mode==M_NONE&&hypotf(dx,dy)>8){
  if(locked)P.mode=dy<0?M_UNLOCK:M_APP;else if(ccP>.5f)P.mode=(ccEdit&&ccCand>=0)?M_CCDRAG:(ccPick?M_APP:(dy<0?M_CCX:M_APP));else if(P.sy<36&&dy>0)P.mode=M_CC;
  else if(P.sy>612&&dy<0){P.mode=M_HOME;editMode=0;if(libOn){libT=0;libOn=0;libEdit=0;kbWant=0;}if(cur>=0){tiox=180;tioy=299;tos0=.56f;torad=40;oa0=1;}}
  else if(!swOn&&cur<0&&editMode&&candId>=0){P.mode=M_DRAG;startDrag();}
  else if(!swOn&&cur<0&&fabsf(dx)>fabsf(dy)&&P.sy>70&&P.sy<525){P.mode=M_HPAGE;hbase=hpT;}
  else if(!swOn&&cur<0&&!editMode&&dy<-10&&fabsf(dy)>fabsf(dx)&&P.sy>70&&P.sy<600){P.mode=M_LIB;libEdit=0;libsc=0;}else P.mode=M_APP;}
 switch(P.mode){case M_UNLOCK:unlockP=unlockT=CL(-dy/660,0,1);break;case M_CC:ccP=ccT=CL(dy/CCH,0,1);break;case M_CCX:ccP=ccT=CL(1+dy/CCH,0,1);break;
  case M_HOME:if(cur>=0)openP=openT=CL(1+dy/420,.25f,1);break;
  case M_DRAG:dragX=x;dragY=y;break;case M_CCDRAG:if(ccDrag<0)ccDrag=ccCand;ccDX=x;ccDY=y;break;case M_HPAGE:hpx=hpT=CL(hbase-dx/360,-.15f,1.15f);break;case M_LIB:libP=libT=CL(-dy/480,0,1);break;
  case M_LIBUI:if(hypotf(dx,dy)>8){libsc=CL(libsc-(y-libsy),0,libmax());libsy=y;}break;
  case M_SW:if(swaxis==0&&hypotf(dx,dy)>8)swaxis=fabsf(dx)>fabsf(dy)?1:(swcard>=0?2:3);if(swaxis==3&&fabsf(dx)>24){swaxis=1;swbase=swPos+dx/210;}
   if(swaxis==1)swPos=swPosT=CL(swbase-dx/210,-.3f,fmaxf(nrec-1,0)+.3f);else if(swaxis==2)dismY[swcard]=fminf(0,dy);break;case M_CCUI:S.br=30+CL((x-48)/280.f,0,1)*70;break;
  case M_NONE:case M_APP:if(!locked&&cur>=0&&openP>.9f&&ccP<.5f)apps[cur].mv(x,y);break;default:break;}}
static void p_up(float x,float y){if(!P.down)return;P.down=0;int m=P.mode;float vy=P.vy;if(booting)return;
 switch(m){case M_UNLOCK:unlockT=(unlockP>.15f||vy<-600)?1:0;break;case M_CC:ccT=(ccP>.35f||vy>500)?1:0;break;case M_CCX:ccT=(ccP<.8f||vy<-500)?0:1;break;
  case M_HOME:if(cur>=0){if(openP<.85f||vy<-600)closeApp();else openT=1;}lay_save();break;
  case M_DRAG:dropIcon(x,y);break;case M_CCDRAG:cc_drop(x,y);break;
  case M_HPAGE:{float vxx=(x-P.sx)/(float)(NOW-P.t0+.01);hpage=vxx<-350?1:vxx>350?0:(hpx>.5f?1:0);hpT=hpage;break;}
  case M_LIB:libT=(libP>.3f||vy<-500)?1:0;libOn=libT>.5f;if(libOn)libEdit=0;break;
  case M_LIBUI:if(hypotf(x-P.sx,y-P.sy)<8)lib_tap(x,y);else if(libsc<=0&&y-P.sy>90){libT=0;libOn=0;libEdit=0;kbWant=0;}break;
  case M_SW:if(swaxis==0){if(P.sy>620){swOn=0;break;}int hit=-1;for(int k=0;k<nrec;k++){float cx=180+(k-swPos)*210;if(in(x,y,cx-101,120+dismY[k],202,358))hit=k;}
    if(hit>=0){int id=rec[hit];float cx=180+(hit-swPos)*210;swOn=0;openApp(id);iox=tiox=cx;ioy=tioy=299;os0=tos0=.56f;orad=torad=40;oa0=1;swHide=id;pushLater=id;}else if(nrec&&in(x,y,120,552,120,36)){for(int k=0;k<nrec;k++)quitApp(rec[k]);nrec=0;swOn=0;}else swOn=0;}
   else if(swaxis==1)swPosT=CL(roundf(swPos),0,fmaxf(nrec-1,0));else if(swaxis==2&&(dismY[swcard]<-90||vy<-500))dismiss(swcard);
   swaxis=0;break;case M_CCUI:sset();break;
  case M_APP:if(!locked&&cur>=0&&ccP<.5f&&apps[cur].up)apps[cur].up(x,y,0);break;
  case M_NONE:{
   if(locked)break;if(ccPick){pick_tap(x,y);break;}if(ccP>.5f){if(y<CCH)cc_tap(x,y);else{if(ccEdit){ccEdit=0;cc_save();}else ccT=0;}break;}
   if(cur>=0){if(y>620&&fabsf(x-180)<70){closeApp();break;}if(apps[cur].up)apps[cur].up(x,y,1);break;}
   if(editMode){if(in(x,y,135,494,90,28)){editMode=0;lay_save();break;}int sl;float cx,cy;int id=homeAt(x,y,&sl,&cx,&cy);
    if(id>=0&&in(x,y,cx-44,cy-44,30,30)){if(sl>=100)dkk[sl-100]=-1;else hs[sl]=-1;lay_save();}else if(id<0)editMode=0;break;}
   if(in(x,y,125,494,110,28)){libT=1;libOn=1;libEdit=1;kbWant=1;libsc=0;break;}
   {int sl;float cx,cy;int id=homeAt(x,y,&sl,&cx,&cy);if(id>=0)activate(id);}break;}
  default:break;}
}
static void frame(float dt){busy=0;slow=0;blurOff=S.noblur;
 term_poll();if(launch>=0&&cur<0){openApp(launch);launch=-1;}if(tpend[0]&&tmfd>=0&&cur==8&&openP>.5f){char cc[310];int l=snprintf(cc,310,"%s\r",tpend);twr(cc,l);tpend[0]=0;}
 if(cur==8)slow=1;
 if(S.br!=lastbr){lastbr=S.br;bl_apply();}
 {float k=fminf(1,dt*16);iox+=(tiox-iox)*k;ioy+=(tioy-ioy)*k;os0+=(tos0-os0)*k;orad+=(torad-orad)*k;}
 if(swOn&&cur<0&&swHide>=0&&pushLater<0)swHide=-1;
 if(pushLater>=0&&swP<.02f){recpush(pushLater);pushLater=-1;swHide=-1;}
 if(P.down&&P.mode==M_HOME&&!swOn&&!locked&&P.sy-P.y>90&&NOW-P.lt>.25){swOn=1;swPos=swPosT=0;if(cur>=0){openT=0;kbWant=0;swHide=cur;}P.mode=M_SW;swaxis=3;swcard=-1;}
 if(booting){bootT+=dt;busy=1;if(bootT>3.5f)booting=0;}
 dt*=ASP[S.anim];
 if(S.autolock&&!locked&&!booting&&NOW-lastIn>ALS[S.autolock])lock();
 #define SM(v,t,k) do{if((v)!=(t)){(v)+=((t)-(v))*fminf(1,dt*(k));if(fabsf((t)-(v))<.002f)(v)=(t);busy=1;}}while(0)
 if(!(P.down&&P.mode==M_UNLOCK))SM(unlockP,unlockT,9);if(!(P.down&&(P.mode==M_CC||P.mode==M_CCX)))SM(ccP,ccT,11);
 if(!(P.down&&P.mode==M_HOME))SM(openP,openT,9);
 if(!(P.down&&P.mode==M_HPAGE))SM(hpx,hpT,12);if(!(P.down&&P.mode==M_LIB))SM(libP,libT,12);lau_sync();
 if(P.down&&P.mode==M_NONE&&!locked&&cur<0&&!swOn&&!libOn&&ccP<.1f&&!booting&&NOW-P.t0>.45&&hypotf(P.x-P.sx,P.y-P.sy)<8&&candId>=0){editMode=1;P.mode=M_DRAG;startDrag();}
 if(P.down&&P.mode==M_DRAG){if((P.x<28&&hpage>0)||(P.x>332&&hpage<1)){edgeT+=dt;if(edgeT>.55f){hpage=P.x<28?0:1;hpT=hpage;edgeT=0;}}else edgeT=0;}
 if(P.down&&P.mode==M_NONE&&ccP>.9f&&!ccEdit&&!ccPick&&ccCand>=0&&!ccslide&&NOW-P.t0>.45&&hypotf(P.x-P.sx,P.y-P.sy)<8){ccEdit=1;P.mode=M_CCDRAG;ccDrag=ccCand;ccDX=P.x;ccDY=P.y;}
 if(ccP<.02f){ccEdit=0;ccPick=0;ccDrag=-1;}{Rc rr[18];cc_layout(rr);}
 if(editMode||dragId>=0||ccEdit)busy=1;float kt=(kbWant&&(cur>=0||libOn))?1:0;SM(kbP,kt,14);
 SM(swP,swOn?1.f:0.f,12);if(!(P.down&&P.mode==M_SW&&swaxis==1))SM(swPos,swPosT,12);for(int k=0;k<10;k++)if(!(P.down&&P.mode==M_SW&&swaxis==2&&swcard==k))SM(dismY[k],0.f,14);if(swOn)busy=1;
 if(unlockP>=.999f&&unlockT==1)locked=0;if(cur>=0&&openT==0&&openP<=.002f){cur=-1;openP=0;}
 if(cur==7&&bfd>=0)busy=1;
 if(P.down||(cur>=0&&apps[cur].live)||ccP>0||unlockP>0&&unlockP<1)busy=1;
 render();
 if(P.down&&!booting){idX();RR(P.x-14,P.y-14,28,28,14,INK(),.12f);}
 {int x0=(int)ceilf(OX),x1=(int)floorf(OX+360*SC),y0=(int)ceilf(OY),y1=(int)floorf(OY+640*SC);
  for(int y=0;y<H;y++){if(y<y0||y>=y1)memset(buf+(size_t)y*W,0,W*4);else{if(x0>0)memset(buf+(size_t)y*W,0,x0*4);if(x1<W)memset(buf+(size_t)y*W+x1,0,(W-x1)*4);}}}}
// ---------- device layer ----------
#ifndef TEST
// ---------- GUI mode: full-screen Linux GUI apps (Wayland via cage); the shell steps aside while they run ----------
static int guiRun,guiPid,guiBdown,gk_ctrl,gk_alt;static double guiKill_t;static float guiY0;
static void gui_kill(void){if(guiPid>0){kill(-guiPid,SIGTERM);guiKill_t=NOW;}}
static void gui_start(const char*cmd){if(guiRun||!cmd[0])return;guiPid=fork();if(!guiPid){setsid();execl("/usr/local/bin/fadan-gui-run","fadan-gui-run",cmd,(char*)0);_exit(127);}guiRun=1;guiBdown=0;gk_ctrl=gk_alt=0;guiKill_t=0;}
typedef struct{int fd,abs,rel,mx,Mx,my,My,mt,slot;}Dev;static Dev dv[32];static int nd;static char opened[32];static float px,py;static int bdown,shift;
static void scan(void){for(int i=0;i<32;i++){if(opened[i])continue;char p[40];snprintf(p,40,"/dev/input/event%d",i);int fd=open(p,O_RDONLY|O_NONBLOCK);if(fd<0)continue;opened[i]=1;
 Dev*d=&dv[nd++];memset(d,0,sizeof*d);d->fd=fd;unsigned char bits[8]={0};ioctl(fd,EVIOCGBIT(0,sizeof bits),bits);d->abs=bits[0]>>EV_ABS&1;d->rel=bits[0]>>EV_REL&1;
 if(d->abs){unsigned char ab[16]={0};ioctl(fd,EVIOCGBIT(EV_ABS,sizeof ab),ab);d->mt=ab[ABS_MT_POSITION_X/8]>>(ABS_MT_POSITION_X%8)&1;struct input_absinfo a;if(d->mt){if(ioctl(fd,EVIOCGABS(ABS_MT_POSITION_X),&a)==0){d->mx=a.minimum;d->Mx=a.maximum;}if(ioctl(fd,EVIOCGABS(ABS_MT_POSITION_Y),&a)==0){d->my=a.minimum;d->My=a.maximum;}}else{if(ioctl(fd,EVIOCGABS(ABS_X),&a)==0){d->mx=a.minimum;d->Mx=a.maximum;}if(ioctl(fd,EVIOCGABS(ABS_Y),&a)==0){d->my=a.minimum;d->My=a.maximum;}}}}}
static int hwctrl;
static void hwkey(int c,int v){if(guiRun){if(c==29||c==97)gk_ctrl=v>0;else if(c==56||c==100)gk_alt=v>0;else if(v>0&&c==16&&gk_ctrl&&gk_alt)gui_kill();return;}lastIn=NOW;if(c==29||c==97){hwctrl=v>0;return;}if(v>0){int k=c==103?0x103:c==108?0x102:c==105?0x101:c==106?0x104:c==1?27:c==15?9:0;if(k){key_in(k);return;}}static const char*r1="qwertyuiop",*r2="asdfghjkl",*r3="zxcvbnm",*r0="1234567890";int ch=0;
 if(c==42||c==54){shift=v>0;return;}if(v==0)return;if(c==14)ch=8;else if(c==28)ch=10;else if(c==57)ch=' ';else if(c==51)ch=',';else if(c==52)ch='.';
 else if(c>=2&&c<=13){static const char*U="1234567890-=",*Sh="!@#$%^&*()_+";ch=shift?Sh[c-2]:U[c-2];}else if(c==26||c==27||c==39||c==40||c==41||c==43||c==53){static const char*U2="[];'`\\/",*S2="{}:\"~|?";int ix=c==26?0:c==27?1:c==39?2:c==40?3:c==41?4:c==43?5:6;ch=shift?S2[ix]:U2[ix];}else if(c>=16&&c<=25)ch=r1[c-16];else if(c>=30&&c<=38)ch=r2[c-30];else if(c>=44&&c<=50)ch=r3[c-44];
 if(ch>='a'&&ch<='z'&&shift)ch-=32;if(hwctrl&&ch>='a'&&ch<='z')ch&=31;if(ch)key_in(ch);}
static void poll_in(int ms){struct pollfd f[32];for(int i=0;i<nd;i++){f[i].fd=dv[i].fd;f[i].events=POLLIN;}poll(f,nd,ms);
 for(int i=0;i<nd;i++){struct input_event e;int ch=0,mv=0;while(read(dv[i].fd,&e,sizeof e)==sizeof e){
  if(e.type==EV_ABS&&dv[i].mt){if(e.code==ABS_MT_SLOT)dv[i].slot=e.value;else if(dv[i].slot==0&&e.code==ABS_MT_POSITION_X&&dv[i].Mx>dv[i].mx){px=(e.value-dv[i].mx)*(float)(W-1)/(dv[i].Mx-dv[i].mx);mv=1;}else if(dv[i].slot==0&&e.code==ABS_MT_POSITION_Y&&dv[i].My>dv[i].my){py=(e.value-dv[i].my)*(float)(H-1)/(dv[i].My-dv[i].my);mv=1;}}
  else if(e.type==EV_ABS){if(e.code==ABS_X&&dv[i].Mx>dv[i].mx){px=(e.value-dv[i].mx)*(float)(W-1)/(dv[i].Mx-dv[i].mx);mv=1;}
   if(e.code==ABS_Y&&dv[i].My>dv[i].my){py=(e.value-dv[i].my)*(float)(H-1)/(dv[i].My-dv[i].my);mv=1;}}
  else if(e.type==EV_REL){if(e.code==REL_X)px=CL(px+e.value,0,W-1);if(e.code==REL_Y)py=CL(py+e.value,0,H-1);mv=1;}
  else if(e.type==EV_KEY){if(e.code==BTN_LEFT||e.code==BTN_TOUCH){bdown=e.value;ch=1;}else hwkey(e.code,e.value);}
  else if(e.type==EV_SYN){float lx=(px-OX)/SC,ly=(py-OY)/SC;if(guiRun){if(ch){if(bdown){guiBdown=1;guiY0=ly;}else{if(guiBdown&&guiY0>610&&ly<guiY0-90)gui_kill();guiBdown=0;}}ch=mv=0;continue;}if(ch){if(bdown)p_down(lx,ly);else p_up(lx,ly);}else if(mv&&P.down)p_move(lx,ly);ch=mv=0;}}}}
static double mono(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static int loadfont(int i,const char*path){FILE*f=fopen(path,"rb");if(!f)return 0;fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);unsigned char*d=malloc(n);if(fread(d,1,n,f)!=(size_t)n){fclose(f);return 0;}fclose(f);return stbtt_InitFont(&FI[i],d,0);}
int main(void){mkdir(SAVE,0755);
 int tty=open("/dev/tty0",O_RDWR);if(tty>=0){ioctl(tty,KDSETMODE,KD_GRAPHICS);(void)!write(tty,"\033[?25l",6);}
 int fb=-1;for(int i=0;i<100&&fb<0;i++){fb=open("/dev/fb0",O_RDWR);if(fb<0)usleep(200000);}if(fb<0)return 1;
 struct fb_fix_screeninfo fi;unsigned char*fp=NULL;size_t fpl=0;
 const char*fr=getenv("FONT"),*fb_=getenv("FONTB");fontok=fr&&loadfont(0,fr);if(fontok){if(!(fb_&&loadfont(1,fb_)))FI[1]=FI[0];}
 {const char*fm=getenv("FONTM");if(!(fm&&loadfont(4,fm)))FI[4]=FI[0];}
 {const char*ff=getenv("FONTF");if(ff&&loadfont(2,ff)){FI[3]=FI[2];fbok=1;}}
 FILE*f=fopen(SAVE"/set.bin","rb");if(f){if(fread(&S,sizeof S,1,f)!=1){}fclose(f);}f=fopen(SAVE"/notes.dat","rb");if(f){if(fread(notes,sizeof notes,1,f)!=1){}fclose(f);}
 init_apps();da_load();lay_load();cc_load();bl_find();settz();{FILE*f=fopen(SAVE"/apn","r");if(f){if(fgets(apn,48,f))apn[strcspn(apn,"\n")]=0;fclose(f);}}if(S.airplane)net_set(0);lastIn=mono();scan();double last=mono(),ls=last,lf=-10,lg=0;px=W/2;py=H/2;
 for(;;){NOW=mono();float dt=fminf(.05f,NOW-last);last=NOW;if(NOW-ls>2){scan();ls=NOW;}
  if(NOW-lf>1){lf=NOW;struct fb_var_screeninfo vi;ioctl(fb,FBIOGET_VSCREENINFO,&vi);ioctl(fb,FBIOGET_FSCREENINFO,&fi);
   if(vi.bits_per_pixel==32&&(!fp||(int)vi.xres!=W||(int)vi.yres!=H)){if(fp)munmap(fp,fpl);W=vi.xres;H=vi.yres;fpl=fi.smem_len;
    fp=mmap(0,fpl,PROT_READ|PROT_WRITE,MAP_SHARED,fb,0);if(fp==MAP_FAILED)return 3;free(buf);free(wpb);free(wpbl);wpbl=NULL;buf=calloc(W*H,4);wpb=calloc(W*H,4);
    SC=fminf(W/360.f,H/640.f);OX=(W-360*SC)/2;OY=(H-640*SC)/2;mkwp();}}
  if(!fp){usleep(100000);continue;}
  if(guiRun){int st;if(guiKill_t>0&&NOW-guiKill_t>1.5&&guiPid>0){kill(-guiPid,SIGKILL);guiKill_t=NOW+9999;}
   if(waitpid(guiPid,&st,WNOHANG)==guiPid){guiRun=0;guiPid=0;{struct fb_var_screeninfo vi;ioctl(fb,FBIOGET_VSCREENINFO,&vi);vi.activate=FB_ACTIVATE_NOW|FB_ACTIVATE_FORCE;ioctl(fb,FBIOPUT_VSCREENINFO,&vi);ioctl(fb,FBIOPAN_DISPLAY,&vi);}
    {int tt=open("/dev/tty0",O_RDWR);if(tt>=0){ioctl(tt,KDSETMODE,KD_GRAPHICS);close(tt);}}P.down=0;lastIn=NOW;}
   else{if(nd)poll_in(50);else usleep(50000);continue;}}
  if(NOW-lg>.4){lg=NOW;FILE*gf=fopen("/run/fadan-gui.cmd","r");if(gf){char gc[300]="";if(fgets(gc,300,gf))gc[strcspn(gc,"\n")]=0;fclose(gf);unlink("/run/fadan-gui.cmd");gui_start(gc);if(guiRun)continue;}}
  if(nd)poll_in(busy?6:(slow?70:400));else usleep(100000);NOW=mono();frame(dt);
  for(int y=0;y<H;y++)memcpy(fp+(size_t)y*fi.line_length,buf+(size_t)y*W,W*4);}}
#endif
