@echo off
rem FadanOS launcher. Needs QEMU for Windows: https://qemu.weilnetz.de/w64/
set QEMU="C:\Program Files\qemu\qemu-system-x86_64.exe"
pushd "%~dp0out"
%QEMU% -name FadanOS -machine q35 -cpu max -accel whpx,kernel-irqchip=off -accel tcg,thread=multi -smp 2 -m 2048 ^
 -kernel vmlinuz-virt -initrd initramfs-virt ^
 -append "root=/dev/vda rootfstype=ext4 rw quiet loglevel=0 console=ttyS0 vt.global_cursor_default=0 video=Virtual-1:360x640" ^
 -drive file=fadanos.img,format=raw,if=virtio ^
 -device virtio-vga,edid=on,xres=360,yres=640 -display gtk,zoom-to-fit=off ^
 -device qemu-xhci -device usb-tablet -device usb-kbd -nic user,model=virtio-net-pci
popd
pause
