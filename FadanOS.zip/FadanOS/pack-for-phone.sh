#!/usr/bin/env bash
# Packs FadanOS for an Android phone (Termux). Run after build.sh. Result: fadanos-phone.tar.gz
set -e; cd "$(dirname "$0")"
[ -f out/fadanos.img ] || { echo "Run build.sh first"; exit 1; }
T=$(mktemp -d); mkdir "$T/fadanos-phone"
cp out/vmlinuz-virt out/initramfs-virt phone/phone-run.sh "$T/fadanos-phone/"
cp --sparse=always out/fadanos.img "$T/fadanos-phone/"
tar --sparse -czf fadanos-phone.tar.gz -C "$T" fadanos-phone; rm -rf "$T"
ls -lh fadanos-phone.tar.gz
